package com.example.foodapp;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Home#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Home extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Home() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Home.
     */
    // TODO: Rename and change types and number of parameters
    public static Home newInstance(String param1, String param2) {
        Home fragment = new Home();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_home, container, false);

        ImageView labelImg = (ImageView) view.findViewById(R.id.labelImg);
        TextView labelTxt = (TextView) view.findViewById(R.id.labelTxt);

        //label1
        int[] labelImg1 = new int[]{R.drawable.n01, R.drawable.n02, R.drawable.n03, R.drawable.n04};
        String[] labelTxt1 = new String[]{"伍玲年代", "忠青商行", " 曼谷魚", "華國早餐店"};

        List<HashMap<String,String>> aList1 = new ArrayList<HashMap<String,String>>();
        for(int i=0;i<4;i++){
            HashMap<String, String> hm = new HashMap<String,String>();
            hm.put("labelImg1", Integer.toString(labelImg1[i]));
            hm.put("labelTxt1", labelTxt1[i]);
            aList1.add(hm);
        }

        String[] from1 = {"labelImg1", "labelTxt1"};
        int[] to1 = {R.id.labelImg, R.id.labelTxt};

        SimpleAdapter adapter1 = new SimpleAdapter(view.getContext(), aList1, R.layout.label1layout, from1, to1);
        GridView gridG1 = (GridView) view.findViewById(R.id.gridG1);
        gridG1.setAdapter(adapter1);

        //label2
        int[] labelImg2 = new int[]{R.drawable.n01, R.drawable.n02, R.drawable.n03, R.drawable.n04};
        String[] labelTxt2 = new String[]{"伍玲年代", "忠青商行", " 曼谷魚", "華國早餐店"};

        List<HashMap<String,String>> aList2 = new ArrayList<HashMap<String,String>>();
        for(int i=0;i<4;i++){
            HashMap<String, String> hm = new HashMap<String,String>();
            hm.put("labelImg2", Integer.toString(labelImg2[i]));
            hm.put("labelTxt2", labelTxt2[i]);
            aList2.add(hm);
        }

        String[] from2 = {"labelImg2", "labelTxt2"};
        int[] to2 = {R.id.labelImg, R.id.labelTxt};

        SimpleAdapter adapter2 = new SimpleAdapter(view.getContext(), aList2, R.layout.label1layout, from2, to2);
        GridView gridG2 = (GridView) view.findViewById(R.id.gridG2);
        gridG2.setAdapter(adapter2);

        //label3
        int[] labelImg3 = new int[]{R.drawable.n01, R.drawable.n02, R.drawable.n03, R.drawable.n04};
        String[] labelTxt3 = new String[]{"伍玲年代", "忠青商行", " 曼谷魚", "華國早餐店"};

        List<HashMap<String,String>> aList3 = new ArrayList<HashMap<String,String>>();
        for(int i=0;i<4;i++){
            HashMap<String, String> hm = new HashMap<String,String>();
            hm.put("labelImg3", Integer.toString(labelImg3[i]));
            hm.put("labelTxt3", labelTxt3[i]);
            aList3.add(hm);
        }

        String[] from3 = {"labelImg3", "labelTxt3"};
        int[] to3 = {R.id.labelImg, R.id.labelTxt};

        SimpleAdapter adapter3 = new SimpleAdapter(view.getContext(), aList3, R.layout.label1layout, from3, to3);
        GridView gridG3 = (GridView) view.findViewById(R.id.gridG3);
        gridG3.setAdapter(adapter3);

        //label4
        int[] labelImg4 = new int[]{R.drawable.n01, R.drawable.n02, R.drawable.n03, R.drawable.n04};
        String[] labelTxt4 = new String[]{"伍玲年代", "忠青商行", " 曼谷魚", "華國早餐店"};

        List<HashMap<String,String>> aList4 = new ArrayList<HashMap<String,String>>();
        for(int i=0;i<4;i++){
            HashMap<String, String> hm = new HashMap<String,String>();
            hm.put("labelImg4", Integer.toString(labelImg4[i]));
            hm.put("labelTxt4", labelTxt4[i]);
            aList4.add(hm);
        }

        String[] from4 = {"labelImg4", "labelTxt4"};
        int[] to4 = {R.id.labelImg, R.id.labelTxt};

        SimpleAdapter adapter4 = new SimpleAdapter(view.getContext(), aList4, R.layout.label1layout, from4, to4);
        GridView gridG4 = (GridView) view.findViewById(R.id.gridG4);
        gridG4.setAdapter(adapter4);
        return view;
    }
}