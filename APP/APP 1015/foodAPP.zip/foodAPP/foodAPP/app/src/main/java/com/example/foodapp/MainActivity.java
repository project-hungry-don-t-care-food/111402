package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.sql.Connection;

public class MainActivity extends AppCompatActivity {

    private TextView login, signup;
    private LinearLayout L1, L2, L3, L4, L5;
    private ImageButton check;
    static Connection connection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        changeColor(R.color.status);

        L1 = (LinearLayout) findViewById(R.id.L1);
        L2 = (LinearLayout) findViewById(R.id.L2);
        L3 = (LinearLayout) findViewById(R.id.L3);
        L4 = (LinearLayout) findViewById(R.id.L4);
        L5 = (LinearLayout) findViewById(R.id.L5);
        login = (TextView) findViewById (R.id.login);
        signup = (TextView) findViewById(R.id.signup);
        check = (ImageButton) findViewById(R.id.check);
        login.setOnClickListener(loginListener);
        signup.setOnClickListener(signupListener);
        check.setOnClickListener(checkListener);

    }


    private View.OnClickListener loginListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ColorStateList oldColors = login.getTextColors();
                    Typeface oldTypes = login.getTypeface();
                    signup.setTextColor(oldColors);
                    signup.setTypeface(oldTypes, Typeface.NORMAL);
                    login.setTextColor(Color.parseColor("#000000"));
                    login.setTypeface(oldTypes, Typeface.BOLD);


                    L1.setVisibility(view.GONE);
                    L2.setVisibility(view.GONE);
                    L3.setVisibility(view.GONE);
                    L4.setVisibility(view.GONE);
                    L5.setVisibility(view.GONE);
                }
            };

    private View.OnClickListener signupListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ColorStateList oldColors = signup.getTextColors();
                    Typeface oldTypes = signup.getTypeface();
                    login.setTextColor(oldColors);
                    login.setTypeface(oldTypes, Typeface.NORMAL);
                    signup.setTextColor(Color.parseColor("#000000"));
                    signup.setTypeface(oldTypes, Typeface.BOLD);


                    L1.setVisibility(view.VISIBLE);
                    L2.setVisibility(view.VISIBLE);
                    L3.setVisibility(view.VISIBLE);
                    L4.setVisibility(view.VISIBLE);
                    L5.setVisibility(view.VISIBLE);
                }
            };

    private View.OnClickListener checkListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    startActivity(intent);
                }
            };
    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}