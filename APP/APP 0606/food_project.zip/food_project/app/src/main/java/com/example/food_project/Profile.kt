
package com.example.food_project

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.ContextMenu
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_ai_search.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_profile.*

class Profile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 21) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = this.resources.getColor(R.color.status)
        }

        setContentView(R.layout.activity_profile)

        profileHome.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        profileSearch.setOnClickListener {
            startActivity(Intent(this, Search::class.java))
        }

        profileNtub.setOnClickListener {
            startActivity(Intent(this, Ntub::class.java))
        }

        profileLoved.setOnClickListener {
            startActivity(Intent(this, Loved::class.java))
        }

        profileAiSearch.setOnClickListener {
            startActivity(Intent(this, AiSearch::class.java))
        }

        imageButton7.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivity(intent)
        }

        registerForContextMenu(findViewById(R.id.menu))

    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menu?.add(0, v?.getId()!!, 0, "修改密碼")
        menu?.add(0, v?.getId()!!, 0, "修改封面圖")
        menu?.add(0, v?.getId()!!, 0, "申請成為店家")
    }
}