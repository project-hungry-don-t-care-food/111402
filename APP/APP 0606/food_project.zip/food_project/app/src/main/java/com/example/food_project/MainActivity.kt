package com.example.food_project

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.SimpleAdapter
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_ai_search.*
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 21) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = this.resources.getColor(R.color.status)
        }


        setContentView(R.layout.activity_main)

        homeSearch.setOnClickListener {
            startActivity(Intent(this, Search::class.java))
        }

        homeNtub.setOnClickListener {
            startActivity(Intent(this, Ntub::class.java))
        }

        homeLoved.setOnClickListener {
            startActivity(Intent(this, Loved::class.java))
        }

        homeAiSearch.setOnClickListener {
            startActivity(Intent(this, AiSearch::class.java))
        }

        homeProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        val imgText1 = arrayListOf("合掌村", "阜杭豆漿")
        val imgId1 = arrayListOf(R.drawable.p11, R.drawable.p12)

        val item1 = ArrayList<Map<String, Any>>()

        for (i in imgId1.indices) {
            val item = HashMap<String, Any>()
            item["imgId1"] = imgId1[i]
            item["imgText1"] = imgText1[i]
            item1.add(item)
        }

        val adapter1 = SimpleAdapter(this,
            item1, R.layout.grid_item1, arrayOf("imgId1", "imgText1"),
            intArrayOf(R.id.gridImg1, R.id.gridText1))

        gridView1.adapter = adapter1

        val imgText2 = arrayListOf("雙月", "巧之味")
        val imgId2 = arrayListOf(R.drawable.p13, R.drawable.p14)

        val item2 = ArrayList<Map<String, Any>>()

        for (i in imgId2.indices) {
            val item = HashMap<String, Any>()
            item["imgId2"] = imgId2[i]
            item["imgText2"] = imgText2[i]
            item2.add(item)
        }

        val adapter2 = SimpleAdapter(this,
            item2, R.layout.grid_item2, arrayOf("imgId2", "imgText2"),
            intArrayOf(R.id.gridImg2, R.id.gridText2))

        gridView2.adapter = adapter2

        val imgText3 = arrayListOf("肯德基", "漢堡王")
        val imgId3 = arrayListOf(R.drawable.p15, R.drawable.p16)

        val item3 = ArrayList<Map<String, Any>>()

        for (i in imgId3.indices) {
            val item = HashMap<String, Any>()
            item["imgId3"] = imgId3[i]
            item["imgText3"] = imgText3[i]
            item3.add(item)
        }

        val adapter3 = SimpleAdapter(this,
            item3, R.layout.grid_item3, arrayOf("imgId3", "imgText3"),
            intArrayOf(R.id.gridImg3, R.id.gridText3))

        gridView3.adapter = adapter3

        val imgText4 = arrayListOf("雙月", "百八魚場")
        val imgId4 = arrayListOf(R.drawable.p17, R.drawable.p18)

        val item4 = ArrayList<Map<String, Any>>()

        for (i in imgId4.indices) {
            val item = HashMap<String, Any>()
            item["imgId4"] = imgId4[i]
            item["imgText4"] = imgText4[i]
            item4.add(item)
        }

        val adapter4 = SimpleAdapter(this,
            item4, R.layout.grid_item4, arrayOf("imgId4", "imgText4"),
            intArrayOf(R.id.gridImg4, R.id.gridText4))

        gridView4.adapter = adapter4

        gridView1.onItemClickListener = object:
            AdapterView.OnItemClickListener{
            override fun onItemClick(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                var intent: Intent? = null
                if (position == 0) {
                    intent = Intent(view?.getContext() !! , sushi::class.java)
                }

                startActivity(intent)

            }

        }

    }
}