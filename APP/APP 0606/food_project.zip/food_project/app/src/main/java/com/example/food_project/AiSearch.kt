package com.example.food_project

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.view.WindowManager
import kotlinx.android.synthetic.main.activity_ai_search.*
import kotlinx.android.synthetic.main.activity_main.*

class AiSearch : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 21) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = this.resources.getColor(R.color.status)
        }

        setContentView(R.layout.activity_ai_search)

        aiSearchHome.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        aiSearchSearch.setOnClickListener {
            startActivity(Intent(this, Search::class.java))
        }

        aiSearchNtub.setOnClickListener {
            startActivity(Intent(this, Ntub::class.java))
        }

        aiSearchLoved.setOnClickListener {
            startActivity(Intent(this, Loved::class.java))
        }

        aiSearchProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        imageButton5.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivity(intent)
        }
    }
}