package com.example.foodapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Ntub#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Ntub extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Ntub() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Ntub.
     */
    // TODO: Rename and change types and number of parameters
    public static Ntub newInstance(String param1, String param2) {
        Ntub fragment = new Ntub();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_ntub, container, false);

        ImageView right = (ImageView) view.findViewById(R.id.right);
        ImageView logo = (ImageView) view.findViewById(R.id.logo);
        ImageView crown = (ImageView) view.findViewById(R.id.crown);
        ImageView left = (ImageView) view.findViewById(R.id.left);
        TextView name = (TextView) view.findViewById(R.id.name);
        TextView street = (TextView) view.findViewById(R.id.street);


        int[] rights = new int[]{R.drawable.n1, R.drawable.n1, R.drawable.n1, R.drawable.n1};
        int[] pics = new int[]{R.drawable.n01, R.drawable.n02, R.drawable.n03, R.drawable.n04};
        int[] crowns = new int[]{R.drawable.n3, R.drawable.n3, R.drawable.n3, R.drawable.n3,};
        String[] names = new String[]{"伍玲年代", "忠青商行", " 曼谷魚", "華國早餐店"};
        String[] strs = new String[]{"台北市中正區杭州路一段5號",
                "台北市中正區青島東路6-1號青島會館二館",
                "台北市中正區青島東路5號",
                "台北市中正區青島東路23號"
        };
        int[] lefts = new int[]{R.drawable.n2, R.drawable.n2, R.drawable.n2, R.drawable.n2};

        List<HashMap<String,String>> aList = new ArrayList<HashMap<String,String>>();
        for(int i=0;i<4;i++){
            HashMap<String, String> hm = new HashMap<String,String>();
            hm.put("rights", Integer.toString(rights[i]));
            hm.put("pics", Integer.toString(pics[i]));
            hm.put("crowns", Integer.toString(crowns[i]));
            hm.put("names", names[i]);
            hm.put("strs", strs[i]);
            hm.put("lefts", Integer.toString(lefts[i]));
            aList.add(hm);
        }

        String[] from = {"rights", "pics", "crowns", "names", "strs", "lefts"};
        int[] to = {R.id.right, R.id.logo, R.id.crown, R.id.name, R.id.street, R.id.left};

        SimpleAdapter adapter = new SimpleAdapter(view.getContext(), aList, R.layout.ntublayout, from, to);

        ListView lst = (ListView) view.findViewById(R.id.lstNtub);
        lst.setAdapter(adapter);
        return view;
    }
}