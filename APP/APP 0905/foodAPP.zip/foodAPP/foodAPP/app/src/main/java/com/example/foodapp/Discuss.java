package com.example.foodapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Discuss#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Discuss extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Discuss() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Discuss.
     */
    // TODO: Rename and change types and number of parameters
    public static Discuss newInstance(String param1, String param2) {
        Discuss fragment = new Discuss();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_discuss, container, false);

        ImageView disImg = (ImageView) view.findViewById(R.id.disImg);
        TextView disTxt = (TextView) view.findViewById(R.id.disTxt);

        int[] disImgs = new int[]{R.drawable.p11, R.drawable.p12, R.drawable.p13, R.drawable.p14};
        String[] disTxts = new String[]{"合掌村", "阜杭豆漿", "雙月", "巧之味"};

        List<HashMap<String,String>> aList = new ArrayList<HashMap<String,String>>();
        for(int i=0;i<4;i++){
            HashMap<String, String> hm = new HashMap<String,String>();
            hm.put("disImgs", Integer.toString(disImgs[i]));
            hm.put("disTxts", disTxts[i]);
            aList.add(hm);
        }

        String[] from = {"disImgs", "disTxts"};
        int[] to = {R.id.disImg, R.id.disTxt};

        SimpleAdapter adapter = new SimpleAdapter(view.getContext(), aList, R.layout.discusslayout, from, to);

        ListView lst = (ListView) view.findViewById(R.id.lstDiscuss);
        lst.setAdapter(adapter);
        return view;
    }
}