package com.example.foodapp;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Loved#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Loved extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Loved() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Loved.
     */
    // TODO: Rename and change types and number of parameters
    public static Loved newInstance(String param1, String param2) {
        Loved fragment = new Loved();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_loved, container, false);

//        TextView textView =  (TextView) view.findViewById(R.id.textView);
//        TextView textView2 =  (TextView) view.findViewById(R.id.textView2);
//        TextView textView3 =  (TextView) view.findViewById(R.id.textView3);
//        TextView textView4 =  (TextView) view.findViewById(R.id.textView4);
//        TextView textView5 =  (TextView) view.findViewById(R.id.textView5);
//
//        ColorStateList oldColors =  textView2.getTextColors();
//        Typeface oldTypes = textView2.getTypeface();
//
//        textView.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                textView.setTextColor(Color.parseColor("#000000"));
//                textView.setTypeface(oldTypes, Typeface.BOLD);
//                textView2.setTextColor(oldColors);
//                textView2.setTypeface(oldTypes, Typeface.NORMAL);
//                textView3.setTextColor(oldColors);
//                textView3.setTypeface(oldTypes, Typeface.NORMAL);
//                textView4.setTextColor(oldColors);
//                textView4.setTypeface(oldTypes, Typeface.NORMAL);
//                textView5.setTextColor(oldColors);
//                textView5.setTypeface(oldTypes, Typeface.NORMAL);
//            }
//        });
//
//        textView2.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                textView.setTextColor(oldColors);
//                textView.setTypeface(oldTypes, Typeface.NORMAL);
//                textView2.setTextColor(Color.parseColor("#000000"));
//                textView2.setTypeface(oldTypes, Typeface.BOLD);
//                textView3.setTextColor(oldColors);
//                textView3.setTypeface(oldTypes, Typeface.NORMAL);
//                textView4.setTextColor(oldColors);
//                textView4.setTypeface(oldTypes, Typeface.NORMAL);
//                textView5.setTextColor(oldColors);
//                textView5.setTypeface(oldTypes, Typeface.NORMAL);
//            }
//        });
//
//        textView3.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                textView.setTextColor(oldColors);
//                textView.setTypeface(oldTypes, Typeface.NORMAL);
//                textView2.setTextColor(oldColors);
//                textView2.setTypeface(oldTypes, Typeface.NORMAL);
//                textView3.setTextColor(Color.parseColor("#000000"));
//                textView3.setTypeface(oldTypes, Typeface.BOLD);
//                textView4.setTextColor(oldColors);
//                textView4.setTypeface(oldTypes, Typeface.NORMAL);
//                textView5.setTextColor(oldColors);
//                textView5.setTypeface(oldTypes, Typeface.NORMAL);
//            }
//        });
//
//        textView4.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                textView.setTextColor(oldColors);
//                textView.setTypeface(oldTypes, Typeface.NORMAL);
//                textView2.setTextColor(oldColors);
//                textView2.setTypeface(oldTypes, Typeface.NORMAL);
//                textView3.setTextColor(oldColors);
//                textView3.setTypeface(oldTypes, Typeface.NORMAL);
//                textView4.setTextColor(Color.parseColor("#000000"));
//                textView4.setTypeface(oldTypes, Typeface.BOLD);
//                textView5.setTextColor(oldColors);
//                textView5.setTypeface(oldTypes, Typeface.NORMAL);
//            }
//        });
//
//        textView5.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v){
//                textView.setTextColor(oldColors);
//                textView.setTypeface(oldTypes, Typeface.NORMAL);
//                textView2.setTextColor(oldColors);
//                textView2.setTypeface(oldTypes, Typeface.NORMAL);
//                textView3.setTextColor(oldColors);
//                textView3.setTypeface(oldTypes, Typeface.NORMAL);
//                textView4.setTextColor(oldColors);
//                textView4.setTypeface(oldTypes, Typeface.NORMAL);
//                textView5.setTextColor(Color.parseColor("#000000"));
//                textView5.setTypeface(oldTypes, Typeface.BOLD);
//            }
//        });


    // Inflate the layout for this fragment
        return view;
    }

}