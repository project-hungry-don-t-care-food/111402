package com.example.foodapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.sql.Connection;
import java.util.Objects;

public class Login extends AppCompatActivity {

    private TextView login, signup;
    private LinearLayout L1, L2, L3, L4, L5;
    private Button loginbtn, signupbtn;
    static Connection connection;

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        String userid = getSharedPreferences("test",MODE_PRIVATE)
                .getString("USER","999");
        if(Objects.equals(userid, "999")){
            AlertDialog.Builder builder = new AlertDialog.Builder(this); //創建訊息方塊
            builder.setMessage("確定要離開？");
            builder.setTitle("尚未登入");
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener()  {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    MainActivity.A.finish();
                    System.exit(0);
                }
            });
            builder.setNegativeButton("取消", new DialogInterface.OnClickListener()  {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.create().show();
        }

        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        changeColor(R.color.status);

        L1 = (LinearLayout) findViewById(R.id.L1);
        L2 = (LinearLayout) findViewById(R.id.L2);
        L3 = (LinearLayout) findViewById(R.id.L3);
        L4 = (LinearLayout) findViewById(R.id.L4);
        L5 = (LinearLayout) findViewById(R.id.L5);
        login = (TextView) findViewById (R.id.login);
        signup = (TextView) findViewById(R.id.signup);
        loginbtn = (Button) findViewById(R.id.loginbtn);
        login.setOnClickListener(loginListener);
        signup.setOnClickListener(signupListener);
        loginbtn.setOnClickListener(logincheckListener);

    }


    private View.OnClickListener loginListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ColorStateList oldColors = login.getTextColors();
                    Typeface oldTypes = login.getTypeface();
                    signup.setTextColor(oldColors);
                    signup.setTypeface(oldTypes, Typeface.NORMAL);
                    login.setTextColor(Color.parseColor("#000000"));
                    login.setTypeface(oldTypes, Typeface.BOLD);

                    L1.setVisibility(view.GONE);
                    L2.setVisibility(view.GONE);
                    L3.setVisibility(view.GONE);
                    L4.setVisibility(view.GONE);
                    L5.setVisibility(view.GONE);
                    loginbtn.setVisibility(view.VISIBLE);
                    signupbtn.setVisibility(view.GONE);

                }
            };

    private View.OnClickListener signupListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ColorStateList oldColors = signup.getTextColors();
                    Typeface oldTypes = signup.getTypeface();
                    login.setTextColor(oldColors);
                    login.setTypeface(oldTypes, Typeface.NORMAL);
                    signup.setTextColor(Color.parseColor("#000000"));
                    signup.setTypeface(oldTypes, Typeface.BOLD);

                    L1.setVisibility(view.VISIBLE);
                    L2.setVisibility(view.VISIBLE);
                    L3.setVisibility(view.VISIBLE);
                    L4.setVisibility(view.VISIBLE);
                    L5.setVisibility(view.VISIBLE);
                    loginbtn.setVisibility(view.GONE);
                    signupbtn.setVisibility(view.VISIBLE);
                }
            };

    private View.OnClickListener logincheckListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedPreferences pref = getSharedPreferences("test", MODE_PRIVATE);
                    pref.edit()
                            .putString("USER","user")
                            .apply();
                    finish();
                }
            };
    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}