package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Resturant extends AppCompatActivity {

    private ImageButton goback;
    private String currentResName, currentResId;
    private TextView rName, rStar, rAddress, rPhone, rWebsite;
    private ImageView rLogo, rCloud, collect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resturant);
        changeColor(R.color.status);

        rLogo = (ImageView) findViewById(R.id.rLogo);
        rName = (TextView) findViewById(R.id.rName);
        rStar = (TextView) findViewById(R.id.rStar);
        rAddress = (TextView) findViewById(R.id.rAddress);
        rPhone = (TextView) findViewById(R.id.rPhone);
        rWebsite = (TextView) findViewById(R.id.rWebsite);
        rCloud = (ImageView) findViewById(R.id.rCloud);

        currentResName = getIntent().getExtras().get("resName").toString();
//        currentResId = (String)getIntent().getExtras().getString("resId");

        Connection connection;

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();

            String sqlstatement = "SELECT store_info_id, store_name, total_score, address, phone_number, url, wordcloud " +
                    "FROM store_info WHERE store_info_id = '"+currentResName+"'";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()) {
                rName.setText(set.getString(2));
                rStar.setText(set.getString(3));
                rAddress.setText(set.getString(4));
                rPhone.setText(set.getString(5));
                rWebsite.setText(set.getString(6)); //網址
                String getSQL = set.getString(7);
                byte[] bytes = Base64.decode(getSQL, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                rCloud.setImageBitmap(bitmap_resize);
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT image FROM store_image where store_info_id = '"+currentResName+"'";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                String getSQL = set.getString(1);
                byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                rLogo.setImageBitmap(bitmap_resize);
            }

            connection.close();
        }catch (Exception e){
            Log.d("SqlCon2",e.toString());
        }


        goback = (ImageButton) findViewById(R.id.goback);
        goback.setOnClickListener(gobackListener);

//        collect = (ImageView) findViewById(R.id.collect);
//        collect.setOnClickListener(collectListener);
    }

    private ImageButton.OnClickListener gobackListener =
            new ImageButton.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            };
/*
    private View.OnClickListener collectListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(Resturant.this, currentResId, Toast.LENGTH_LONG).show();
                    Toast.makeText(Resturant.this, currentResName, Toast.LENGTH_LONG).show();
                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();

                        String sqlstatement = "INSERT INTO member_collection_id (member_id, store_info_id) VALUES ('"+currentResId+"','"+currentResName+"')";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon1",e.toString());
                    }
                }
            };

 */

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}
