package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Profile_Edit extends AppCompatActivity {
    private TextView Paccount;
    private EditText Ppassword, Pname, Pbirth;
    private Spinner Pgenderchoose, Pdepartmentchoose, Pgradechoose;
    private Button pCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_edit);
        changeColor(R.color.status);

        Connection connection;
        Paccount = findViewById(R.id.Paccount);
        Ppassword = findViewById(R.id.Ppassword);
        Pname =findViewById(R.id.Pname);
        Pbirth = findViewById(R.id.Pbirth);
        Pgenderchoose = findViewById(R.id.Pgenderchoose);
        Pdepartmentchoose = findViewById(R.id.Pdepartmentchoose);
        Pgradechoose = findViewById(R.id.Pgradechoose);
        pCancel = findViewById(R.id.pCancel);
        pCancel.setOnClickListener(pcancelListener);
        String oName = "";
        String oGender = "";
        String oBirth = "";
        String oGrade = "";
        String oDepartment = "";

        String userid = getSharedPreferences("user_info", MODE_PRIVATE)
                .getString("USER", "999");

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT member_id, account, (name), gender, convert(date,birthday,111), grade, trim(department) FROM member WHERE (member_id = "+ userid + ")";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                Paccount.setText(set.getString(2));
                oName = set.getString(3);
                oGender = set.getString(4);
                oBirth = set.getString(5);
                oGrade = set.getString(6);
                oDepartment = set.getString(7);
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }
        //name
        Pname.setText(oName);
        //gender
        if (oGender.equals("1")) {
            Pgenderchoose.setSelection(1);
        }else if(oGender.equals("2")){
            Pgenderchoose.setSelection(2);
        }else if(oGender.equals("3")){
            Pgenderchoose.setSelection(3);
        }
        //birth
        Pbirth.setText(oBirth);
        //grade
        if (oGrade.equals("1")){
            Pgradechoose.setSelection(1);
        }else if (oGrade.equals("2")) {
            Pgradechoose.setSelection(2);
        }else if (oGrade.equals("3")) {
            Pgradechoose.setSelection(3);
        }else if (oGrade.equals("4")) {
            Pgradechoose.setSelection(4);
        }else if (oGrade.equals("5")) {
            Pgradechoose.setSelection(5);
        }
        //department
        if (oDepartment.equals("資訊管理系")){
            Pdepartmentchoose.setSelection(1);
        }else if (oDepartment.equals("企業管理系")){
            Pdepartmentchoose.setSelection(2);
        }else if (oDepartment.equals("應用外語系")){
            Pdepartmentchoose.setSelection(3);
        }else if (oDepartment.equals("財政稅務系")){
            Pdepartmentchoose.setSelection(4);
        }else if (oDepartment.equals("財務金融系")){
            Pdepartmentchoose.setSelection(5);
        }else if (oDepartment.equals("國際商務系")){
            Pdepartmentchoose.setSelection(6);
        }else if (oDepartment.equals("會計資訊系")){
            Pdepartmentchoose.setSelection(7);
        }
    }

    private View.OnClickListener pcancelListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            };

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}