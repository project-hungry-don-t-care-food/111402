package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class New_Local_Comment extends AppCompatActivity {
    private static final int IMAGE_REQUEST_CODE = 0;
    TextView new_comment_store_name;
    EditText new_comment_input_title;
    NumberPicker new_comment_input_score;
    EditText new_comment_input_content;
    Button new_comment_button_upload_image;
    ImageView new_comment_input_image;
    Button new_comment_button_commit;
    Button new_comment_button_cancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_local_comment);
        changeColor(R.color.status);

        new_comment_store_name = findViewById(R.id.new_comment_store_name);
        new_comment_input_title = findViewById(R.id.new_comment_input_title);
        new_comment_input_score = findViewById(R.id.new_comment_input_score);
        new_comment_input_content = findViewById(R.id.new_comment_input_content);
        new_comment_button_upload_image = findViewById(R.id.new_comment_button_upload_image);
        new_comment_input_image = findViewById(R.id.new_comment_input_image);
        new_comment_button_commit = findViewById(R.id.new_comment_button_commit);
        new_comment_button_cancel = findViewById(R.id.new_comment_button_cancel);

        String store_info_id = getIntent().getExtras().get("res_id").toString();
        String store_info_name = getIntent().getExtras().get("res_name").toString();

        new_comment_store_name.setText("店家：" + store_info_name);

        new_comment_input_score.setValue(0);
        new_comment_input_score.setMaxValue(5);
        new_comment_input_score.setMinValue(0);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            new_comment_input_score.setTextSize(45);
            new_comment_input_score.setWrapSelectorWheel(false);
        }

        new_comment_button_upload_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, IMAGE_REQUEST_CODE);
            }
        });

        new_comment_input_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(New_Local_Comment.this, "長按可移除圖片", Toast.LENGTH_SHORT).show();
            }
        });
        new_comment_input_image.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new_comment_input_image.setImageBitmap(null);
                return false;
            }
        });

        new_comment_button_commit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String create_time = date.format(new Date());

                String title = new_comment_input_title.getText().toString();
                String member_id = getSharedPreferences("user_info",MODE_PRIVATE)
                        .getString("USER","999");
                String score = String.valueOf(new_comment_input_score.getValue());
                String content = new_comment_input_content.getText().toString().replace("\n","\\n");

                String string_of_image = "";
                if (new_comment_input_image.getDrawable() != null){
                    Bitmap bitmap = ((BitmapDrawable) new_comment_input_image.getDrawable()).getBitmap();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] imageInByte = baos.toByteArray();
                    string_of_image = Base64.encodeToString(imageInByte,Base64.DEFAULT);
                }

                String like_num = "0";

                if(title.replace(" ","").equals("") || content.replace(" ","").replace("\\n","").equals("")){
                    Toast.makeText(New_Local_Comment.this, "請輸入標題及內容", Toast.LENGTH_LONG).show();
                }else {
                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "INSERT INTO store_local_comment (store_info_id, create_time, title, member_id, score, [content], image, like_num) " +
                                "VALUES (" + store_info_id + ", CONVERT(DATETIME, '" + create_time + "', 102), " +
                                "N'" + title + "', " + member_id + ", " + score + ", '" + content + "', N'" + string_of_image + "', " + like_num + ")";
                        Statement smt = connection.createStatement();
                        int set = smt.executeUpdate(sqlstatement);

                        connection.close();
                    } catch (Exception e) {
                        Log.d("SqlCon1", e.toString());
                    }
                    Toast.makeText(getApplicationContext(), "已送出", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });

        new_comment_button_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case IMAGE_REQUEST_CODE://這裡的requestCode是我自己設定的，就是確定返回到那個Activity的標誌
                if (resultCode == RESULT_OK) {//resultcode是setResult裡面設定的code值
                    try {
                        Uri selectedImage = data.getData(); //獲取系統返回的照片的Uri
                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
                        Cursor cursor = getContentResolver().query(selectedImage,
                                filePathColumn, null, null, null);//從系統表中查詢指定Uri對應的照片
                        cursor.moveToFirst();
                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                        String path = cursor.getString(columnIndex);  //獲取照片路徑
                        cursor.close();
                        Bitmap bitmap = BitmapFactory.decodeFile(path);
                        new_comment_input_image.setImageBitmap(bitmap);
                    } catch (Exception e) {
                        // TODO Auto-generatedcatch block
                        Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();
                        Log.d("image",e.toString());
                    }
                }
                break;
        }
    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}