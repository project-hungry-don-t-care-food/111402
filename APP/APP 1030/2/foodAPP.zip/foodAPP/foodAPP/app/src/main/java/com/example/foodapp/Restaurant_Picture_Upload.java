package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Restaurant_Picture_Upload extends AppCompatActivity {

    private ImageButton Uback;
    private ImageView pictureupload, picture01, picture02, picture03, picture1, picture2, picture3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_picture_upload);
        changeColor(R.color.status);

        Uback = (ImageButton) findViewById(R.id.Uback);
        pictureupload = (ImageView) findViewById(R.id.pictureupload);
        picture01 = (ImageView) findViewById(R.id.picture01);
        picture02 = (ImageView) findViewById(R.id.picture02);
        picture03 = (ImageView) findViewById(R.id.picture03);
        picture1 = (ImageView) findViewById(R.id.picture1);
        picture2 = (ImageView) findViewById(R.id.picture2);
        picture3 = (ImageView) findViewById(R.id.picture3);

        Uback.setOnClickListener(UbackListener);
    }

   private View.OnClickListener UbackListener=
           new View.OnClickListener() {
               @Override
               public void onClick(View view) {
                   finish();
               }
           };

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}