package com.example.foodapp;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Loved#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Loved extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Loved() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Loved.
     */
    // TODO: Rename and change types and number of parameters
    public static Loved newInstance(String param1, String param2) {
        Loved fragment = new Loved();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_loved, container, false);
        GridView collectList = (GridView) view.findViewById(R.id.collectList);

        Connection connection;
        String userid = getContext().getSharedPreferences("test", MODE_PRIVATE)
                .getString("USER", "999");
        List<Bitmap> image = new ArrayList<Bitmap>();
        List<String> id = new ArrayList<String>();
        List<String> name = new ArrayList<String>();

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT store_info_id FROM member_collection_id WHERE (member_id = " + userid + ") ORDER BY create_time DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()) {
                id.add(set.getString(1));
            }
            connection.close();
        } catch (Exception e) {
            Log.d("SqlCon1", e.toString());
        }

        for (int count = 0; count < id.size(); count++) {
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT store_name FROM store_info WHERE store_info_id = " + id.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()) {
                    name.add(set.getString(1));
                }
                connection.close();
            } catch (Exception e) {
                Log.d("SqlCon2", e.toString());
            }

            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image WHERE (store_info_id = "+ id.get(count)+") AND (Label = N'3')";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()) {
                    if (set.getString(1).equals("")){
                        image.add(null);
                    }else {
                        byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        image.add(bitmap_resize);
                    }
                }
                connection.close();
            } catch (Exception e) {
                Log.d("SqlCon3", e.toString());
            }
        }

        collectView adasport = new collectView(getContext(), image, name);
        collectList.setAdapter(adasport);

        collectList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        return view;
    }

    public static class collectView extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        public collectView(Context context, List<Bitmap> image, List<String> name){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = image;
            adapter_names = name;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.collectlayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.collectImg);
            TextView name = (TextView) view.findViewById(R.id.collectTxt);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));

            return view;
        }
    }

}