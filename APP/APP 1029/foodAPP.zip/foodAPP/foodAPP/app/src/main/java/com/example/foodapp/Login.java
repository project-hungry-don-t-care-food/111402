package com.example.foodapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Objects;

public class Login extends AppCompatActivity {

    private TextView login, signup;
    private EditText Laccount, Lpassword, Lname, Lbirth;
    private Spinner genderchoose, gradechoose, departmentchoose;
    private LinearLayout L1, L2, L3, L4, L5;
    private Button loginbtn, signupbtn;
    static Connection connection;

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        String userid = getSharedPreferences("test",MODE_PRIVATE)
                .getString("USER","999");
        if(Objects.equals(userid, "999")){
            AlertDialog.Builder builder = new AlertDialog.Builder(this); //創建訊息方塊
            builder.setMessage("確定要離開？");
            builder.setTitle("尚未登入");
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener()  {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    MainActivity.Main_Activity.finish();
                    System.exit(0);
                }
            });
            builder.setNegativeButton("取消", new DialogInterface.OnClickListener()  {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.create().show();
        }

        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        changeColor(R.color.status);

        L1 = (LinearLayout) findViewById(R.id.L1);
        L2 = (LinearLayout) findViewById(R.id.L2);
        L3 = (LinearLayout) findViewById(R.id.L3);
        L4 = (LinearLayout) findViewById(R.id.L4);
        L5 = (LinearLayout) findViewById(R.id.L5);
        Laccount = (EditText) findViewById(R.id.Laccount);
        Lpassword = (EditText) findViewById(R.id.Lpassword);
        Lname = (EditText) findViewById(R.id.Lname);
        Lbirth = (EditText) findViewById(R.id.Lbirth);
        genderchoose = (Spinner) findViewById(R.id.genderchoose);
        gradechoose = (Spinner) findViewById(R.id.gradechoose);
        departmentchoose = (Spinner) findViewById(R.id.departmentchoose);
        login = (TextView) findViewById (R.id.login);
        signup = (TextView) findViewById(R.id.signup);
        loginbtn = (Button) findViewById(R.id.loginbtn);
        signupbtn = (Button) findViewById(R.id.signupbtn);
        login.setOnClickListener(loginListener);
        signup.setOnClickListener(signupListener);
        loginbtn.setOnClickListener(logincheckListener);
        signupbtn.setOnClickListener(signupcheckListener);

    }

    private View.OnClickListener loginListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    login.setTextColor(Color.BLACK);
                    login.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                    signup.setTextColor(Color.GRAY);
                    signup.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                    L1.setVisibility(View.GONE);
                    L2.setVisibility(View.GONE);
                    L3.setVisibility(View.GONE);
                    L4.setVisibility(View.GONE);
                    L5.setVisibility(View.GONE);
                    loginbtn.setVisibility(View.VISIBLE);
                    signupbtn.setVisibility(View.GONE);

                }
            };

    private View.OnClickListener signupListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    signup.setTextColor(Color.BLACK);
                    signup.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                    login.setTextColor(Color.GRAY);
                    login.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                    L1.setVisibility(View.VISIBLE);
                    L2.setVisibility(View.VISIBLE);
                    L3.setVisibility(View.VISIBLE);
                    L4.setVisibility(View.VISIBLE);
                    L5.setVisibility(View.VISIBLE);
                    loginbtn.setVisibility(View.GONE);
                    signupbtn.setVisibility(View.VISIBLE);
                }
            };

    private View.OnClickListener logincheckListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedPreferences pref = getSharedPreferences("test", MODE_PRIVATE);
//                    pref.edit()
//                            .putString("USER","2")
//                            .apply();
//                    finish();
                    if (Laccount.length() == 0){
                        Toast.makeText(Login.this, "!請輸入帳號!", Toast.LENGTH_SHORT).show();
                    }

                    if (Lpassword.length() == 0){
                        Toast.makeText(Login.this, "!請輸入密碼!", Toast.LENGTH_SHORT).show();
                    }
                    String loginAccount = Laccount.getText().toString();
                    String loginPassword = Lpassword.getText().toString();
                    String userid = "";
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "SELECT member_id, account, password FROM member WHERE (account = N'"+loginAccount+"') AND (password = N'"+loginPassword+"')" ;
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        while (set.next()){
                            userid = set.getString(1);
//                            if(set.getString(2).equals(loginAccount) || set.getString(3).equals(loginPassword)){
//                                Toast.makeText(Login.this, "!帳號或密碼錯誤!", Toast.LENGTH_SHORT).show();
//                            }else {
//                                userid = set.getString(1);
//                            }
                        }
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon2",e.toString());
                    }
                    pref.edit()
                            .putString("USER",userid)
                            .apply();
                    Intent intent = new Intent(Login.this, MainActivity.class);
                    startActivity(intent);
                }
            };

    private View.OnClickListener signupcheckListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String account = Laccount.getText().toString();
                    String password = Lpassword.getText().toString();
                    String name = Lname.getText().toString();
                    String gendertxt = genderchoose.getSelectedItem().toString();
                    int gender = 0;
                    String gradetxt = gradechoose.getSelectedItem().toString();
                    int grade = 0;
                    String birth = Lbirth.getText().toString();
                    String department = departmentchoose.getSelectedItem().toString();

                    if (gendertxt.equals("男")){
                        gender = 1;
                    }else if (gendertxt.equals("女")){
                        gender = 2;
                    }else if (gendertxt.equals("其他")){
                        gender = 3;
                    }

                    if (gradetxt.equals("一")){
                        grade = 1;
                    }else if (gradetxt.equals("二")){
                        grade = 2;
                    }else if (gradetxt.equals("三")){
                        grade = 3;
                    }else if (gradetxt.equals("四")){
                        grade = 4;
                    }else if (gradetxt.equals("五")){
                        grade = 5;
                    }

                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "INSERT INTO member (create_time, account, password, name, gender, birthday, grade, department) VALUES " +
                                "(getdate(), N'"+account+"',N'"+password+"',N'"+name+"',"+gender+",convert(date, "+birth+"),"+grade+",N'"+department+"')" ;
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        while (set.next()){}
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon2",e.toString());
                    }
                    Toast.makeText(Login.this, "註冊成功", Toast.LENGTH_SHORT).show();

                    signup.setTextColor(Color.BLACK);
                    signup.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                    login.setTextColor(Color.GRAY);
                    login.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                    login.setTextColor(Color.BLACK);
                    login.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                    signup.setTextColor(Color.GRAY);
                    signup.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                    L1.setVisibility(View.GONE);
                    L2.setVisibility(View.GONE);
                    L3.setVisibility(View.GONE);
                    L4.setVisibility(View.GONE);
                    L5.setVisibility(View.GONE);
                    loginbtn.setVisibility(View.VISIBLE);
                    signupbtn.setVisibility(View.GONE);

                    Laccount.setText(null);
                    Lpassword.setText(null);
                    Lname.setText(null);
                    genderchoose.setSelection(0);
                    Lbirth.setText(null);
                    gradechoose.setSelection(0);
                    departmentchoose.setSelection(0);
                }
            };
    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}