package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DiscussOfRestaurant extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discuss_of_restaurant);
        changeColor(R.color.status);

//        String store_info_id = getIntent().getExtras().get("res_id").toString();
        String store_info_name = getIntent().getExtras().get("res_name").toString();
        String store_info_id = "73";

        TextView discussStoreName = findViewById(R.id.discussStoreName);
        TextView discussLastest = findViewById(R.id.discussLastest);
        TextView discussPopular = findViewById(R.id.discussPopular);
        Button newComment = findViewById(R.id.newComment);
        ListView listView = findViewById(R.id.lstDiscussOfRestaurant);
        ListView listView2 = findViewById(R.id.lstDiscussOfRestaurant2);
        listView2.setVisibility(View.GONE);

        List<String> member_name = new ArrayList<>();
        List<Bitmap> member_avator = new ArrayList<>();
        List<String> create_time = new ArrayList<>();
        List<String> title = new ArrayList<>();
        List<String> score = new ArrayList<>();
        List<String> content = new ArrayList<>();
        List<String> like_num = new ArrayList<>();
        List<String> comment_id = new ArrayList<>();

        List<String> member_name2 = new ArrayList<>();
        List<Bitmap> member_avator2 = new ArrayList<>();
        List<String> create_time2 = new ArrayList<>();
        List<String> title2 = new ArrayList<>();
        List<String> score2 = new ArrayList<>();
        List<String> content2 = new ArrayList<>();
        List<String> like_num2 = new ArrayList<>();
        List<String> comment_id2 = new ArrayList<>();

        discussStoreName.setText(store_info_name);
        Connection connection;
//        listView排序。最新
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT member_id, create_time, ISNULL(title, N'無標題'), score, [content], like_num, local_comment_id " +
                    "FROM store_local_comment " +
                    "WHERE (store_info_id = " + store_info_id + ")" +
                    "ORDER BY create_time DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                create_time.add(set.getString(2).substring(0,16));
                title.add(set.getString(3));
                score.add(set.getString(4));
                content.add(set.getString(5));
                like_num.add(set.getString(6));
                comment_id.add(set.getString(7));

                String sqlstatement2 = "SELECT name, avatar FROM member WHERE (member_id = " + set.getString(1) + ")";
                Statement smt2 = connection.createStatement();
                ResultSet set2 = smt2.executeQuery(sqlstatement2);
                while (set2.next()){
                    member_name.add(set2.getString(1));

                    if (set2.getString(2).equals("")){
                        member_avator.add(null);
                    }else {
                        byte[] bytes = Base64.decode(set2.getString(2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 300, 300, false);
                        member_avator.add(bitmap_resize);
                    }
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }
        discussListview discussListview = new discussListview(getApplicationContext(),member_name,member_avator,create_time,title,score,content,like_num);
        listView.setAdapter(discussListview);
//        listView排序。最熱門
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT member_id, create_time, ISNULL(title, N'無標題'), score, [content], like_num, local_comment_id " +
                    "FROM store_local_comment " +
                    "WHERE (store_info_id = " + store_info_id + ")" +
                    "ORDER BY like_num DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                create_time2.add(set.getString(2).substring(0,16));
                title2.add(set.getString(3));
                score2.add(set.getString(4));
                content2.add(set.getString(5));
                like_num2.add(set.getString(6));
                comment_id2.add(set.getString(7));

                String sqlstatement2 = "SELECT name, avatar FROM member WHERE (member_id = " + set.getString(1) + ")";
                Statement smt2 = connection.createStatement();
                ResultSet set2 = smt2.executeQuery(sqlstatement2);
                while (set2.next()){
                    member_name2.add(set2.getString(1));

                    if (set2.getString(2).equals("")){
                        member_avator2.add(null);
                    }else {
                        byte[] bytes = Base64.decode(set2.getString(2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 300, 300, false);
                        member_avator2.add(bitmap_resize);
                    }
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }
        discussListview discussListview2 = new discussListview(getApplicationContext(),member_name2,member_avator2,create_time2,title2,score2,content2,like_num2);
        listView2.setAdapter(discussListview2);

        discussLastest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                discussLastest.setTextColor(Color.BLACK);
                discussLastest.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                discussPopular.setTextColor(Color.GRAY);
                discussPopular.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                listView.setVisibility(View.VISIBLE);
                listView2.setVisibility(View.GONE);
            }
        });
        discussPopular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                discussPopular.setTextColor(Color.BLACK);
                discussPopular.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                discussLastest.setTextColor(Color.GRAY);
                discussLastest.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                listView.setVisibility(View.GONE);
                listView2.setVisibility(View.VISIBLE);
            }
        });
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), discuss_detail.class);
                intent.putExtra("comment_id", comment_id.get(i));
                intent.putExtra("member_name", member_name.get(i));
                intent.putExtra("member_avator", member_avator.get(i));
                intent.putExtra("create_time", create_time.get(i));
                intent.putExtra("title", title.get(i));
                intent.putExtra("score", score.get(i));
                intent.putExtra("content", content.get(i));
                intent.putExtra("like_num", like_num.get(i));

                startActivity(intent);
            }
        });
        listView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getApplicationContext(), discuss_detail.class);
                intent.putExtra("comment_id", comment_id2.get(i));
                intent.putExtra("member_name", member_name2.get(i));
                intent.putExtra("member_avator", member_avator2.get(i));
                intent.putExtra("create_time", create_time2.get(i));
                intent.putExtra("title", title2.get(i));
                intent.putExtra("score", score2.get(i));
                intent.putExtra("content", content2.get(i));
                intent.putExtra("like_num", like_num2.get(i));

                startActivity(intent);
            }
        });

        newComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), New_Local_Comment.class);
                intent.putExtra("res_id", store_info_id);
                intent.putExtra("res_name", store_info_name);
                startActivity(intent);
            }
        });



    }

    public static class discussListview extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        List<Bitmap> adapter_avator;
        List<String> adapter_member_name;
        List<String> adapter_create_time;
        List<String> adapter_title;
        List<String> adapter_score;
        List<String> adapter_content;
        List<String> adapter_like_num;

        public discussListview(Context context, List<String> member_name, List<Bitmap> member_avator, List<String> create_time, List<String> title, List<String> score, List<String> content, List<String> like_num){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_member_name = member_name;
            adapter_avator = member_avator;
            adapter_create_time = create_time;
            adapter_title = title;
            adapter_score = score;
            adapter_content = content;
            adapter_like_num = like_num;
        }
        @Override
        public int getCount() {
            return adapter_member_name.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = listlayoutInflater.inflate(R.layout.discuss_of_restaurant_layout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView avator = convertView.findViewById(R.id.discuss_detail_avator);
            TextView writer = convertView.findViewById(R.id.discuss_detail_writer);
            TextView create_time = convertView.findViewById(R.id.discuss_detail_create_time);
            TextView title = convertView.findViewById(R.id.discuss_title);
            TextView content = convertView.findViewById(R.id.discuss_content);
            TextView likenum = convertView.findViewById(R.id.discuss_like_times);

            avator.setImageBitmap(adapter_avator.get(position));
            writer.setText(adapter_member_name.get(position));
            create_time.setText(adapter_create_time.get(position));
            title.setText(adapter_title.get(position).replace("\\n","\n"));
            content.setText(adapter_content.get(position).replace("\\n","\n"));
            likenum.setText(adapter_like_num.get(position));
            return convertView;
        }
    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}