package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

public class Ai_Search extends AppCompatActivity {
    ImageButton aiBack;

    private static final int IMAGE_REQUEST_CODE = 0;
    ImageView aipictureupload;
    Button AI_food_check;
    TextView Ai_text, Ai_text2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ai_search);
        changeColor(R.color.status);

        aiBack = findViewById(R.id.aiBack);

        aiBack.setOnClickListener(view -> finish());

        aipictureupload = findViewById(R.id.aipictureupload);
        AI_food_check = findViewById(R.id.AI_food_check);
        Ai_text = findViewById(R.id.Ai_text);
        Ai_text2 = findViewById(R.id.Ai_text2);

        aipictureupload.setOnClickListener(view -> {
            Intent intent = new Intent(
                    Intent.ACTION_PICK,
                    android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, IMAGE_REQUEST_CODE);
        });

        AI_food_check.setOnClickListener(view -> {
            if (aipictureupload.getDrawable() != null){
                aipictureupload.setBackground(null);

                Bitmap bitmap = ((BitmapDrawable) aipictureupload.getDrawable()).getBitmap();
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                byte[] imageInByte = baos.toByteArray();
                String string_of_image = Base64.encodeToString(imageInByte,Base64.DEFAULT);

                RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                String url = "http://20.3.171.50:5000/food_categorical";
                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>()
                        {
                            @Override
                            public void onResponse(String response) {
                                // response
                                Log.d("Response", response);
                                String[] temp = response.split(",");
                                Ai_text2.setText(temp[0]);

                                if (Float.parseFloat(temp[1]) >= 0.9){
                                    Ai_text.setText("高機率是 ");
                                }else if (Float.parseFloat(temp[1]) >= 0.7){
                                    Ai_text.setText("有可能是 ");
                                }else{
                                    Ai_text.setText("低機率是 ");
                                }
                                Ai_text.setVisibility(View.VISIBLE);
                                Ai_text2.setVisibility(View.VISIBLE);
                            }
                        },
                        new Response.ErrorListener()
                        {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // error
                                Toast.makeText(Ai_Search.this, "AI辨識出錯，請手動選擇類別", Toast.LENGTH_LONG).show();
                                Log.d("Error.Response", error.toString());
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams()
                    {
                        Map<String, String>  params = new HashMap<String, String>();
                        params.put("str_of_image", string_of_image);

                        return params;
                    }
                };
                queue.add(postRequest);
            }else {
                Toast.makeText(Ai_Search.this, "尚未選擇圖片", Toast.LENGTH_SHORT).show();
            }
        });




    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case IMAGE_REQUEST_CODE://這裡的requestCode是我自己設定的，就是確定返回到那個Activity的標誌
                if (resultCode == RESULT_OK) {//resultcode是setResult裡面設定的code值
                    try {
                        Uri selectedImage = data.getData(); //獲取系統返回的照片的Uri
                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
                        Cursor cursor = getContentResolver().query(selectedImage,
                                filePathColumn, null, null, null);//從系統表中查詢指定Uri對應的照片
                        cursor.moveToFirst();
                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                        String path = cursor.getString(columnIndex);  //獲取照片路徑
                        cursor.close();
                        Bitmap bitmap = BitmapFactory.decodeFile(path);
                        aipictureupload.setImageBitmap(bitmap);
                    } catch (Exception e) {
                        // TODO Auto-generatedcatch block
                        Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();
                        Log.d("image",e.toString());
                    }
                }
                break;
        }
    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}