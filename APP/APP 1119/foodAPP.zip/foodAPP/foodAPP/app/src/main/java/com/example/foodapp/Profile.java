package com.example.foodapp;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Profile#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Profile extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private TextView name, gender, birth, department, grade;
    private ImageView avatar;

    public Profile() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Profile.
     */
    // TODO: Rename and change types and number of parameters
    public static Profile newInstance(String param1, String param2) {
        Profile fragment = new Profile();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
//        name = getContext().findViewById(R.id.nameProfile);
//        gender = getView().findViewById(R.id.gender);
//        birth = getView().findViewById(R.id.birth);
//        department =getView().findViewById(R.id.department);
//        grade = getView().findViewById(R.id.grade);
//        avatar = getView().findViewById(R.id.avatar);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        name = (TextView)view.findViewById(R.id.nameProfile);
        gender = (TextView) view.findViewById(R.id.gender);
        birth = (TextView) view.findViewById(R.id.birth);
        department = (TextView) view.findViewById(R.id.department);
        grade = (TextView) view.findViewById(R.id.grade);
        avatar = (ImageView) view.findViewById(R.id.avatar);
        ImageButton Pedit = (ImageButton) view.findViewById(R.id.Pedit);
        Button logout = (Button) view.findViewById(R.id.logout);
        ImageButton changeavatar = (ImageButton) view.findViewById(R.id.changeavatar);

        Connection connection;
        String userid = getContext().getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("USER","-999");
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT member_id, trim(name), gender, convert(date,birthday,111), grade, trim(department), avatar FROM member WHERE (member_id = "+ userid + ")";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                name.setText(set.getString(2));
                if (set.getString(3).equals("1")) {
                    gender.setText("男");
                }else if(set.getString(3).equals("2")){
                    gender.setText("女");
                }else{
                    gender.setText("其他");
                }
                birth.setText(set.getString(4));
                grade.setText(set.getString(5));
                department.setText(set.getString(6));
                if (set.getString(7).equals("")){
                    avatar.setImageBitmap(null);
                }else {
                    byte[] bytes = Base64.decode(set.getString(7),Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 300, 300, false);
                    avatar.setImageBitmap(bitmap_resize);
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences pref = getContext().getSharedPreferences("user_info", MODE_PRIVATE);
                pref.edit()
                        .clear()
                        .commit();

                MainActivity.Main_Activity.finish();
                Intent intent = new Intent(getContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        Pedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Profile_Edit.class);
                startActivity(intent);
            }
        });

        changeavatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Avatar_Upload.class);
                startActivity(intent);
            }
        });

       // Inflate the layout for this fragment
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Connection connection;

        String userid = getContext().getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("USER","-999");
        String modify_profile_edit = getContext().getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("modify_profile_edit","");
        String modify_user_avatar =  getContext().getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("modify_user_avatar","");

        Log.d("SqlCon81",modify_profile_edit);
        Log.d("SqlCon82",modify_user_avatar);


        if (modify_profile_edit.equals("1")){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT member_id, trim(name), gender, convert(date,birthday,111), grade, trim(department) FROM member WHERE (member_id = "+ userid + ")";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    name.setText(set.getString(2));
                    if (set.getString(3).equals("1")) {
                        gender.setText("男");
                    }else if(set.getString(3).equals("2")){
                        gender.setText("女");
                    }else{
                        gender.setText("其他");
                    }
                    birth.setText(set.getString(4));
                    grade.setText(set.getString(5));
                    department.setText(set.getString(6));
                }
                connection.close();

                SharedPreferences pref = getContext().getSharedPreferences("user_info", MODE_PRIVATE);
                pref.edit()
                        .remove("modify_profile_edit")
                        .apply();

            }catch (Exception e){
                Log.d("SqlCon1",e.toString());
            }
        }

        if (modify_user_avatar.equals("1")){
            avatar.setImageBitmap(null);
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT avatar FROM member WHERE (member_id = "+ userid + ")";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    if (set.getString(1).equals("")){
                        avatar.setImageBitmap(null);
                    }else {
                        byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 300, 300, false);
                        avatar.setImageBitmap(bitmap_resize);
                    }
                }
                connection.close();

                SharedPreferences pref = getContext().getSharedPreferences("user_info", MODE_PRIVATE);
                pref.edit()
                        .remove("modify_user_avatar")
                        .apply();

            }catch (Exception e){
                Log.d("SqlCon2",e.toString());
            }
        }
    }
}