package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.Statement;

public class Avatar_Upload extends AppCompatActivity {
    private static final int IMAGE_REQUEST_CODE = 0;
    private ImageButton Aback;
    private ImageView avatarupload;
    private Button uploadbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avatar_upload);
        changeColor(R.color.status);

        Aback = findViewById(R.id.Aback);
        avatarupload = findViewById(R.id.avatarupload);
        uploadbtn = findViewById(R.id.uploadbtn);

        Aback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        avatarupload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, IMAGE_REQUEST_CODE);
            }
        });

        uploadbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String string_of_image = "";
                Connection connection;
                String userid = getSharedPreferences("user_info", MODE_PRIVATE)
                        .getString("USER", "-999");

                if (avatarupload.getDrawable() != null){
                    avatarupload.setBackground(null);

                    Bitmap bitmap = ((BitmapDrawable) avatarupload.getDrawable()).getBitmap();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] imageInByte = baos.toByteArray();
                    string_of_image = Base64.encodeToString(imageInByte, Base64.DEFAULT);

                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "UPDATE member SET avatar = '"+string_of_image+"' WHERE (member_id = "+ userid + ")";
                        Statement smt = connection.createStatement();
                        int set = smt.executeUpdate(sqlstatement);
                        connection.close();
                        Toast.makeText(Avatar_Upload.this, "已變更頭像", Toast.LENGTH_SHORT).show();
                        SharedPreferences pref = getSharedPreferences("user_info", MODE_PRIVATE);
                        pref.edit()
                                .putString("modify_user_avatar", "1")
                                .apply();
                        finish();
                    } catch (Exception e) {
                        Log.d("SqlCon1", e.toString());
                    }
                }else{
                    Toast.makeText(Avatar_Upload.this, "請點擊圖片上傳圖片", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case IMAGE_REQUEST_CODE://這裡的requestCode是我自己設定的，就是確定返回到那個Activity的標誌
                if (resultCode == RESULT_OK) {//resultcode是setResult裡面設定的code值
                    try {
                        Uri selectedImage = data.getData(); //獲取系統返回的照片的Uri
                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
                        Cursor cursor = getContentResolver().query(selectedImage,
                                filePathColumn, null, null, null);//從系統表中查詢指定Uri對應的照片
                        cursor.moveToFirst();
                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                        String path = cursor.getString(columnIndex);  //獲取照片路徑
                        cursor.close();
                        Bitmap bitmap = BitmapFactory.decodeFile(path);
                        avatarupload.setImageBitmap(bitmap);
                    } catch (Exception e) {
                        // TODO Auto-generatedcatch block
                        Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();
                        Log.d("image",e.toString());
                    }
                }
                break;
        }
    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}