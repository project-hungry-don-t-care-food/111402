package com.example.foodapp;

import android.app.Activity;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Ntub#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Ntub extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;


    public Ntub() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Ntub.
     */
    // TODO: Rename and change types and number of parameters
    public static Ntub newInstance(String param1, String param2) {
        Ntub fragment = new Ntub();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_ntub, container, false);

        ImageView logo = (ImageView) view.findViewById(R.id.logo);
        TextView name = (TextView) view.findViewById(R.id.name);
        TextView address = (TextView) view.findViewById(R.id.address);

//        int[] pics = new int[]{R.drawable.n01, R.drawable.n02, R.drawable.n03, R.drawable.n04};
//        String[] names = new String[]{"伍玲年代", "忠青商行", " 曼谷魚", "華國早餐店"};

        Connection connection;
        List<String> names = new ArrayList<String>();
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT store_name FROM store_info";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                names.add(set.getString(1));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }


        List<String> adds = new ArrayList<String>();
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT address FROM store_info";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                adds.add(set.getString(1));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon2",e.toString());
        }

        List<HashMap<String,String>> aList = new ArrayList<HashMap<String,String>>();
        for(int i=0;i<15;i++){
            HashMap<String, String> hm = new HashMap<String,String>();
//            hm.put("pics", Integer.toString(pics[i]));
            hm.put("names", names.get(i));
            hm.put("adds", adds.get(i));
            aList.add(hm);
        }


        String[] from = {"names", "adds"};
        int[] to = {R.id.name, R.id.address};

        SimpleAdapter adapter = new SimpleAdapter(view.getContext(), aList, R.layout.ntublayout, from, to);

        ListView lst = (ListView) view.findViewById(R.id.lstNtub);
        lst.setAdapter(adapter);
        return view;
    }
}