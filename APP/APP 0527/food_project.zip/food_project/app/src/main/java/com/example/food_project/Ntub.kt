package com.example.food_project

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import android.widget.SimpleAdapter
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_ntub.*
import kotlinx.android.synthetic.main.activity_search.*

class Ntub : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 21) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = this.resources.getColor(R.color.status)
        }

        setContentView(R.layout.activity_ntub)

        ntubHome.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        ntubSearch.setOnClickListener {
            startActivity(Intent(this, Search::class.java))
        }

        ntubLoved.setOnClickListener {
            startActivity(Intent(this, Loved::class.java))
        }

        ntubAiSearch.setOnClickListener {
            startActivity(Intent(this, AiSearch::class.java))
        }

        ntubProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        val img = arrayListOf(R.drawable.p31, R.drawable.p32, R.drawable.p33, R.drawable.p34)

        val items = ArrayList<Map<String, Any>>()

        for (i in img.indices) {
            val item = HashMap<String, Any>()
            item["imageButton4"] = img[i]
            items.add(item)
        }

        val adapter = SimpleAdapter(this,
            items, R.layout.mylayout3, arrayOf("imageButton4"),
            intArrayOf(R.id.imageButton4))

        listView3.adapter = adapter
    }
}