package com.example.foodapp;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Profile#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Profile extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Profile() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Profile.
     */
    // TODO: Rename and change types and number of parameters
    public static Profile newInstance(String param1, String param2) {
        Profile fragment = new Profile();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        TextView name = (TextView)view.findViewById(R.id.nameProfile);
        TextView gender = (TextView) view.findViewById(R.id.gender);
        TextView birth = (TextView) view.findViewById(R.id.birth);
        TextView department = (TextView) view.findViewById(R.id.department);
        TextView grade = (TextView) view.findViewById(R.id.grade);
        ImageView avatar = (ImageView) view.findViewById(R.id.avatar);
        ImageButton Pedit = (ImageButton) view.findViewById(R.id.Pedit);
        Button logout = (Button) view.findViewById(R.id.logout);
        ImageButton changeavatar = (ImageButton) view.findViewById(R.id.changeavatar);

        Connection connection;
        String userid = getContext().getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("USER","999");
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT member_id, trim(name), gender, convert(date,birthday,111), grade, trim(department), avatar FROM member WHERE (member_id = "+ userid + ")";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                name.setText(set.getString(2));
                if (set.getString(3).equals("1")) {
                    gender.setText("男");
                }else if(set.getString(3).equals("2")){
                    gender.setText("女");
                }else{
                    gender.setText("其他");
                }
                birth.setText(set.getString(4));
                grade.setText(set.getString(5));
                department.setText(set.getString(6));
                if (set.getString(7).equals("")){
                    avatar.setImageBitmap(null);
                }else {
                    byte[] bytes = Base64.decode(set.getString(7),Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 300, 300, false);
                    avatar.setImageBitmap(bitmap_resize);
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences pref = getContext().getSharedPreferences("user_info", MODE_PRIVATE);
                pref.edit()
                        .clear()
                        .commit();

                MainActivity.Main_Activity.finish();
                Intent intent = new Intent(getContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        Pedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Profile_Edit.class);
                startActivity(intent);
            }
        });

        changeavatar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), Avatar_Upload.class);
                startActivity(intent);
            }
        });

       // Inflate the layout for this fragment
        return view;
    }
}