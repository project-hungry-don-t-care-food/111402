package com.example.foodapp;

import static android.view.View.VISIBLE;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class Restaurant_Comment extends AppCompatActivity {

    private ImageButton cBack, star1, star2, star3, star4, star5, star01, star02, star03, star04, star05;
    private Button cCancel, cSubmit;
    private EditText cComment, cTitle;
    private String rCurrentResId, userid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_comment);
        changeColor(R.color.status);

        rCurrentResId = getIntent().getExtras().get("cResName").toString();
        userid = getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("USER","999");

        cBack = (ImageButton) findViewById(R.id.cBack);
        cBack.setOnClickListener(cBackListener);
        cCancel = (Button) findViewById(R.id.cCancel);
        cCancel.setOnClickListener(cCancelListener);
        cSubmit = (Button) findViewById(R.id.cSubmit);
        cSubmit.setOnClickListener(cSubmitListener);
        cTitle = (EditText) findViewById(R.id.cTitle);
        cComment = (EditText) findViewById(R.id.cComment);
        star1 = (ImageButton) findViewById(R.id.star1);
        star2 = (ImageButton) findViewById(R.id.star2);
        star3 = (ImageButton) findViewById(R.id.star3);
        star4 = (ImageButton) findViewById(R.id.star4);
        star5 = (ImageButton) findViewById(R.id.star5);
        star01 = (ImageButton) findViewById(R.id.star01);
        star02 = (ImageButton) findViewById(R.id.star02);
        star03 = (ImageButton) findViewById(R.id.star03);
        star04 = (ImageButton) findViewById(R.id.star04);
        star05 = (ImageButton) findViewById(R.id.star05);
        star1.setOnClickListener(star1Listener);
        star2.setOnClickListener(star2Listener);
        star3.setOnClickListener(star3Listener);
        star4.setOnClickListener(star4Listener);
        star01.setOnClickListener(star01Listener);
        star02.setOnClickListener(star02Listener);
        star03.setOnClickListener(star03Listener);
        star04.setOnClickListener(star04Listener);
        star05.setOnClickListener(star05Listener);

    }

    private View.OnClickListener cBackListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            };

    private View.OnClickListener cCancelListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    cTitle.setText(null);
                    cComment.setText(null);
                    star01.setVisibility(VISIBLE);
                    star1.setVisibility(View.INVISIBLE);
                    star02.setVisibility(VISIBLE);
                    star2.setVisibility(View.INVISIBLE);
                    star03.setVisibility(VISIBLE);
                    star3.setVisibility(View.INVISIBLE);
                    star04.setVisibility(VISIBLE);
                    star4.setVisibility(View.INVISIBLE);
                    star05.setVisibility(VISIBLE);
                    star5.setVisibility(View.INVISIBLE);
                }
            };

    private View.OnClickListener star1Listener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    star02.setVisibility(VISIBLE);
                    star2.setVisibility(View.INVISIBLE);
                    star03.setVisibility(VISIBLE);
                    star3.setVisibility(View.INVISIBLE);
                    star04.setVisibility(VISIBLE);
                    star4.setVisibility(View.INVISIBLE);
                    star05.setVisibility(VISIBLE);
                    star5.setVisibility(View.INVISIBLE);
                }
            };

    private View.OnClickListener star2Listener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    star03.setVisibility(VISIBLE);
                    star3.setVisibility(View.INVISIBLE);
                    star04.setVisibility(VISIBLE);
                    star4.setVisibility(View.INVISIBLE);
                    star05.setVisibility(VISIBLE);
                    star5.setVisibility(View.INVISIBLE);
                }
            };

    private View.OnClickListener star3Listener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    star04.setVisibility(VISIBLE);
                    star4.setVisibility(View.INVISIBLE);
                    star05.setVisibility(VISIBLE);
                    star5.setVisibility(View.INVISIBLE);
                }
            };

    private View.OnClickListener star4Listener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    star05.setVisibility(VISIBLE);
                    star5.setVisibility(View.INVISIBLE);
                }
            };


    private View.OnClickListener star01Listener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    star01.setVisibility(View.INVISIBLE);
                    star1.setVisibility(VISIBLE);
                }
            };

    private View.OnClickListener star02Listener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    star01.setVisibility(View.INVISIBLE);
                    star1.setVisibility(VISIBLE);
                    star02.setVisibility(View.INVISIBLE);
                    star2.setVisibility(VISIBLE);
                }
            };

    private View.OnClickListener star03Listener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    star01.setVisibility(View.INVISIBLE);
                    star1.setVisibility(VISIBLE);
                    star02.setVisibility(View.INVISIBLE);
                    star2.setVisibility(VISIBLE);
                    star03.setVisibility(View.INVISIBLE);
                    star3.setVisibility(VISIBLE);
                }
            };

    private View.OnClickListener star04Listener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    star01.setVisibility(View.INVISIBLE);
                    star1.setVisibility(VISIBLE);
                    star02.setVisibility(View.INVISIBLE);
                    star2.setVisibility(VISIBLE);
                    star03.setVisibility(View.INVISIBLE);
                    star3.setVisibility(VISIBLE);
                    star04.setVisibility(View.INVISIBLE);
                    star4.setVisibility(VISIBLE);
                }
            };

    private View.OnClickListener star05Listener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    star01.setVisibility(View.INVISIBLE);
                    star1.setVisibility(VISIBLE);
                    star02.setVisibility(View.INVISIBLE);
                    star2.setVisibility(VISIBLE);
                    star03.setVisibility(View.INVISIBLE);
                    star3.setVisibility(VISIBLE);
                    star04.setVisibility(View.INVISIBLE);
                    star4.setVisibility(VISIBLE);
                    star05.setVisibility(View.INVISIBLE);
                    star5.setVisibility(VISIBLE);
                }
            };

    private View.OnClickListener cSubmitListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String cTContent = cTitle.getText().toString();
                    String cContent = cComment.getText().toString();
                    Integer cScore = 0;
                    if (star5.getVisibility() == VISIBLE){
                        cScore = 5;
                    }else if (star4.getVisibility() == VISIBLE){
                        cScore = 4;
                    }else if (star3.getVisibility() == VISIBLE){
                        cScore = 3;
                    }else if (star2.getVisibility() == VISIBLE){
                        cScore = 2;
                    }else if (star1.getVisibility() == VISIBLE){
                        cScore = 1;
                    }
                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "INSERT INTO store_local_comment (store_info_id, create_time, title, member_id, score, content, like_num) " +
                                "VALUES ("+rCurrentResId+", convert(varchar,getdate(),20), N'"+cTContent+"', "+userid+", "+cScore+", N'"+cContent+"', 0)";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon1",e.toString());
                    }
                    Toast.makeText(Restaurant_Comment.this, "已送出", Toast.LENGTH_SHORT).show();
                    finish();
                }
            };

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}
