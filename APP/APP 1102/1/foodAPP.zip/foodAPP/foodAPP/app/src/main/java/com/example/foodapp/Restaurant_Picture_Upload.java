package com.example.foodapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class Restaurant_Picture_Upload extends AppCompatActivity {
    private static final int IMAGE_REQUEST_CODE = 0;
    private ImageButton Uback;
    private ImageView pictureupload, picture01, picture02, picture03, picture1, picture2, picture3;
    private Button AI_food_menu, upload;
    private String label = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant_picture_upload);
        changeColor(R.color.status);

        String store_info_id = getIntent().getExtras().get("cResName").toString();

        Uback = (ImageButton) findViewById(R.id.Uback);
        pictureupload = (ImageView) findViewById(R.id.pictureupload);
        picture01 = (ImageView) findViewById(R.id.picture01);
        picture02 = (ImageView) findViewById(R.id.picture02);
        picture03 = (ImageView) findViewById(R.id.picture03);
        picture1 = (ImageView) findViewById(R.id.picture1);
        picture2 = (ImageView) findViewById(R.id.picture2);
        picture3 = (ImageView) findViewById(R.id.picture3);
        AI_food_menu = findViewById(R.id.AI_food_menu);
        upload = (Button) findViewById(R.id.upload);

        Uback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        pictureupload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, IMAGE_REQUEST_CODE);
            }
        });

        picture01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                picture01.setVisibility(View.INVISIBLE);
                picture1.setVisibility(View.VISIBLE);

                picture02.setVisibility(View.VISIBLE);
                picture03.setVisibility(View.VISIBLE);
                picture2.setVisibility(View.INVISIBLE);
                picture3.setVisibility(View.INVISIBLE);

                label = "0";
            }
        });

        picture02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                picture02.setVisibility(View.INVISIBLE);
                picture2.setVisibility(View.VISIBLE);

                picture01.setVisibility(View.VISIBLE);
                picture03.setVisibility(View.VISIBLE);
                picture1.setVisibility(View.INVISIBLE);
                picture3.setVisibility(View.INVISIBLE);

                label = "1";
            }
        });

        picture03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                picture03.setVisibility(View.INVISIBLE);
                picture3.setVisibility(View.VISIBLE);

                picture01.setVisibility(View.VISIBLE);
                picture02.setVisibility(View.VISIBLE);
                picture1.setVisibility(View.INVISIBLE);
                picture2.setVisibility(View.INVISIBLE);

                label = "2";
            }
        });

        AI_food_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pictureupload.getDrawable() != null){
                    pictureupload.setBackground(null);

                    Bitmap bitmap = ((BitmapDrawable) pictureupload.getDrawable()).getBitmap();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] imageInByte = baos.toByteArray();
                    String string_of_image = Base64.encodeToString(imageInByte,Base64.DEFAULT);

                    RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
                    String url = "http://20.3.171.50:5000/food_menu";
                    StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                            new Response.Listener<String>()
                            {
                                @Override
                                public void onResponse(String response) {
                                    // response
                                    Log.d("Response", response);
                                    String[] temp = response.split(",");
                                    switch (temp[0]){
                                        case "食物":
                                            picture01.setVisibility(View.INVISIBLE);
                                            picture1.setVisibility(View.VISIBLE);

                                            picture02.setVisibility(View.VISIBLE);
                                            picture03.setVisibility(View.VISIBLE);
                                            picture2.setVisibility(View.INVISIBLE);
                                            picture3.setVisibility(View.INVISIBLE);
                                            label = "0";
                                            break;
                                        case "非食物":
                                            picture02.setVisibility(View.INVISIBLE);
                                            picture2.setVisibility(View.VISIBLE);

                                            picture01.setVisibility(View.VISIBLE);
                                            picture03.setVisibility(View.VISIBLE);
                                            picture1.setVisibility(View.INVISIBLE);
                                            picture3.setVisibility(View.INVISIBLE);
                                            label = "1";
                                            break;
                                        case "菜單":
                                            picture03.setVisibility(View.INVISIBLE);
                                            picture3.setVisibility(View.VISIBLE);

                                            picture01.setVisibility(View.VISIBLE);
                                            picture02.setVisibility(View.VISIBLE);
                                            picture1.setVisibility(View.INVISIBLE);
                                            picture2.setVisibility(View.INVISIBLE);
                                            label = "2";
                                            break;
                                    }
                                }
                            },
                            new Response.ErrorListener()
                            {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    // error
                                    Toast.makeText(Restaurant_Picture_Upload.this, "AI辨識出錯，請手動選擇類別", Toast.LENGTH_LONG).show();
                                    Log.d("Error.Response", error.toString());
                                }
                            }
                    ) {
                        @Override
                        protected Map<String, String> getParams()
                        {
                            Map<String, String>  params = new HashMap<String, String>();
                            params.put("str_of_image", string_of_image);

                            return params;
                        }
                    };
                    queue.add(postRequest);
                }else {
                    Toast.makeText(Restaurant_Picture_Upload.this, "尚未選擇圖片", Toast.LENGTH_SHORT).show();
                }
            }
        });

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Response_label",label);
                if (pictureupload.getDrawable() == null){
                    Toast.makeText(Restaurant_Picture_Upload.this, "尚未選擇圖片", Toast.LENGTH_SHORT).show();
                }else if (label.equals("")){
                    Toast.makeText(Restaurant_Picture_Upload.this, "請選擇類別", Toast.LENGTH_SHORT).show();
                }else{
                    Bitmap bitmap = ((BitmapDrawable) pictureupload.getDrawable()).getBitmap();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] imageInByte = baos.toByteArray();
                    String string_of_image = Base64.encodeToString(imageInByte,Base64.DEFAULT);

                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "INSERT INTO store_image " +
                                "(store_info_id, create_time, image, label, is_from_store_owner) " +
                                "VALUES (" + store_info_id + ", GETDATE(), '" + string_of_image + "', N'" + label + "', 0)";
                        Statement smt = connection.createStatement();
                        int set = smt.executeUpdate(sqlstatement);
                        connection.close();

                        Toast.makeText(Restaurant_Picture_Upload.this, "圖片上傳成功", Toast.LENGTH_SHORT).show();
                        finish();
                    } catch (Exception e) {
                        Log.d("SqlCon1", e.toString());
                        Toast.makeText(Restaurant_Picture_Upload.this, "圖片上傳失敗，請重新嘗試", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case IMAGE_REQUEST_CODE://這裡的requestCode是我自己設定的，就是確定返回到那個Activity的標誌
                if (resultCode == RESULT_OK) {//resultcode是setResult裡面設定的code值
                    try {
                        Uri selectedImage = data.getData(); //獲取系統返回的照片的Uri
                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
                        Cursor cursor = getContentResolver().query(selectedImage,
                                filePathColumn, null, null, null);//從系統表中查詢指定Uri對應的照片
                        cursor.moveToFirst();
                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                        String path = cursor.getString(columnIndex);  //獲取照片路徑
                        cursor.close();
                        Bitmap bitmap = BitmapFactory.decodeFile(path);
                        pictureupload.setImageBitmap(bitmap);
                    } catch (Exception e) {
                        // TODO Auto-generatedcatch block
                        Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();
                        Log.d("image",e.toString());
                    }
                }
                break;
        }
    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}