package com.example.foodapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.dustinredmond.BCrypt;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Objects;

public class Login extends AppCompatActivity {

    private TextView login, signup;
    private EditText Laccount, Lpassword, Lname, Lbirth;
    private Spinner genderchoose, gradechoose, departmentchoose;
    private LinearLayout L1, L2, L3, L4, L5;
    private Button loginbtn, signupbtn;
    static Connection connection;

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        String userid = getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("USER","999");
        if(Objects.equals(userid, "999")){
            AlertDialog.Builder builder = new AlertDialog.Builder(this); //創建訊息方塊
            builder.setMessage("確定要離開？");
            builder.setTitle("尚未登入");
            builder.setPositiveButton("確認", new DialogInterface.OnClickListener()  {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    MainActivity.Main_Activity.finish();
                    System.exit(0);
                }
            });
            builder.setNegativeButton("取消", new DialogInterface.OnClickListener()  {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.create().show();
        }

        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        changeColor(R.color.status);

        L1 = (LinearLayout) findViewById(R.id.L1);
        L2 = (LinearLayout) findViewById(R.id.L2);
        L3 = (LinearLayout) findViewById(R.id.L3);
        L4 = (LinearLayout) findViewById(R.id.L4);
        L5 = (LinearLayout) findViewById(R.id.L5);
        Laccount = (EditText) findViewById(R.id.Laccount);
        Lpassword = (EditText) findViewById(R.id.Lpassword);
        Lname = (EditText) findViewById(R.id.Lname);
        Lbirth = (EditText) findViewById(R.id.Lbirth);
        genderchoose = (Spinner) findViewById(R.id.genderchoose);
        gradechoose = (Spinner) findViewById(R.id.gradechoose);
        departmentchoose = (Spinner) findViewById(R.id.departmentchoose);
        login = (TextView) findViewById (R.id.login);
        signup = (TextView) findViewById(R.id.signup);
        loginbtn = (Button) findViewById(R.id.loginbtn);
        signupbtn = (Button) findViewById(R.id.signupbtn);
        login.setOnClickListener(loginListener);
        signup.setOnClickListener(signupListener);
        loginbtn.setOnClickListener(logincheckListener);
        signupbtn.setOnClickListener(signupcheckListener);

    }

    private View.OnClickListener loginListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    login.setTextColor(Color.BLACK);
                    login.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                    signup.setTextColor(Color.GRAY);
                    signup.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                    L1.setVisibility(View.GONE);
                    L2.setVisibility(View.GONE);
                    L3.setVisibility(View.GONE);
                    L4.setVisibility(View.GONE);
                    L5.setVisibility(View.GONE);
                    loginbtn.setVisibility(View.VISIBLE);
                    signupbtn.setVisibility(View.GONE);

                }
            };

    private View.OnClickListener signupListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    signup.setTextColor(Color.BLACK);
                    signup.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                    login.setTextColor(Color.GRAY);
                    login.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                    L1.setVisibility(View.VISIBLE);
                    L2.setVisibility(View.VISIBLE);
                    L3.setVisibility(View.VISIBLE);
                    L4.setVisibility(View.VISIBLE);
                    L5.setVisibility(View.VISIBLE);
                    loginbtn.setVisibility(View.GONE);
                    signupbtn.setVisibility(View.VISIBLE);
                }
            };

    private View.OnClickListener logincheckListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedPreferences pref = getSharedPreferences("user_info", MODE_PRIVATE);
//                    pref.edit()
//                            .putString("USER","2")
//                            .apply();

                    if (Laccount.length() == 0){
                        Toast.makeText(Login.this, "請輸入帳號", Toast.LENGTH_SHORT).show();
                    }else if (Lpassword.length() == 0){
                        Toast.makeText(Login.this, "請輸入密碼", Toast.LENGTH_SHORT).show();
                    }else{
                        String userid = "";
                        String user_account = "";
                        String user_password = "";

                        String loginAccount = Laccount.getText().toString();
                        String loginPassword = Lpassword.getText().toString();
                        try {
                            ConSQL c = new ConSQL();
                            connection = c.conclass();
                            String sqlstatement = "SELECT member_id, account, password FROM member WHERE (account = N'"+loginAccount+"')";
                            Statement smt = connection.createStatement();
                            ResultSet set = smt.executeQuery(sqlstatement);
                            while (set.next()){
                                userid = set.getString(1);
                                user_account = set.getString(2);
                                user_password = set.getString(3);
                            }
                            connection.close();

                            if (userid.equals("")){
                                Toast.makeText(Login.this, "帳號不存在，請註冊後再登入", Toast.LENGTH_SHORT).show();
                            }else{
                                loginPassword = Crypt.getSHA512(Crypt.getSHA512(loginPassword));
                                if(!BCrypt.checkpw(loginPassword,user_password)){
                                    Toast.makeText(Login.this, "密碼錯誤", Toast.LENGTH_SHORT).show();
                                }else{
                                    pref.edit()
                                            .putString("USER",userid)
                                            .apply();
                                    finish();
                                }
                            }
                        }catch (Exception e){
                            Log.d("SqlCon1",e.toString());
                        }
//                        Intent intent = new Intent(Login.this, MainActivity.class);
//                        startActivity(intent);
                    }
                }
            };

    private View.OnClickListener signupcheckListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String account = Laccount.getText().toString();
                    String password = Lpassword.getText().toString();
                    String name = Lname.getText().toString();
                    String gendertxt = genderchoose.getSelectedItem().toString();
                    int gender = 0;
                    String birth = Lbirth.getText().toString();
                    String department = departmentchoose.getSelectedItem().toString();
                    String gradetxt = gradechoose.getSelectedItem().toString();
                    int grade = 0;


                    if (account.replace(" ", "").equals("")){
                        Toast.makeText(Login.this, "請輸入帳號", Toast.LENGTH_SHORT).show();
                    }else if (password.replace(" ", "").equals("")){
                        Toast.makeText(Login.this, "請輸入密碼", Toast.LENGTH_SHORT).show();
                    }else if (name.replace(" ", "").equals("")){
                        Toast.makeText(Login.this, "請輸入姓名", Toast.LENGTH_SHORT).show();
                    }else if (gendertxt.equals("請選擇性別")){
                        Toast.makeText(Login.this, "請選擇性別", Toast.LENGTH_SHORT).show();
                    }else if (birth.replace(" ", "").equals("")){
                        Toast.makeText(Login.this, "請輸入生日", Toast.LENGTH_SHORT).show();
                    }else if (!birth_isValid(birth)){
                        Toast.makeText(Login.this, "生日格式錯誤(Ex:2000-09-01)", Toast.LENGTH_SHORT).show();
                    }else if (department.equals("請選擇科系")){
                        Toast.makeText(Login.this, "請選擇科系", Toast.LENGTH_SHORT).show();
                    }else if (gradetxt.equals("請選擇年級")){
                        Toast.makeText(Login.this, "請選擇年級", Toast.LENGTH_SHORT).show();
                    }else{
                        switch (gendertxt) {
                            case "男":
                                gender = 1;
                                break;
                            case "女":
                                gender = 2;
                                break;
                            case "其他":
                                gender = 3;
                                break;
                        }
                        switch (gradetxt) {
                            case "一":
                                grade = 1;
                                break;
                            case "二":
                                grade = 2;
                                break;
                            case "三":
                                grade = 3;
                                break;
                            case "四":
                                grade = 4;
                                break;
                            case "五":
                                grade = 5;
                                break;
                        }

                        password = Crypt.getSHA512(Crypt.getSHA512(password));
                        password = BCrypt.hashpw(password, BCrypt.gensalt());

                        try {
                            ConSQL c = new ConSQL();
                            connection = c.conclass();
                            String sqlstatement = "INSERT INTO member (create_time, account, password, name, gender, birthday, grade, department) VALUES " +
                                    "(getdate(), N'"+account+"',N'"+password+"',N'"+name+"',"+gender+",convert(date, '"+birth+"'),"+grade+",N'"+department+"')" ;
                            Statement smt = connection.createStatement();
                            int set = smt.executeUpdate(sqlstatement);
//                            while (set.next()){}
                            connection.close();

                            Toast.makeText(Login.this, "註冊成功，請登入", Toast.LENGTH_SHORT).show();

                            signup.setTextColor(Color.BLACK);
                            signup.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                            login.setTextColor(Color.GRAY);
                            login.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                            login.setTextColor(Color.BLACK);
                            login.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
                            signup.setTextColor(Color.GRAY);
                            signup.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));

                            L1.setVisibility(View.GONE);
                            L2.setVisibility(View.GONE);
                            L3.setVisibility(View.GONE);
                            L4.setVisibility(View.GONE);
                            L5.setVisibility(View.GONE);
                            loginbtn.setVisibility(View.VISIBLE);
                            signupbtn.setVisibility(View.GONE);

//                        Laccount.setText(null);
                            Lpassword.setText(null);
                            Lname.setText(null);
                            genderchoose.setSelection(0);
                            Lbirth.setText(null);
                            departmentchoose.setSelection(0);
                            gradechoose.setSelection(0);
                        }catch (Exception e){
                            Log.d("SqlCon2",e.toString());

                            Toast.makeText(Login.this, "註冊失敗，請重新註冊", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            };

    public boolean birth_isValid(String date){
        DateFormat format = new SimpleDateFormat("yyyy-mm-dd");
        format.setLenient(false);
        try {
            format.parse(date);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}