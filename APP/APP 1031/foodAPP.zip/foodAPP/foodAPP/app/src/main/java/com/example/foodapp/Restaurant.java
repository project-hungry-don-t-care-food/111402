package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Restaurant extends AppCompatActivity {

    private ImageButton goback, map;
    private String currentResId, userid;
    private TextView rName, rStar, rAddress, rPhone, rWebsite, rlabel;
    private ImageView rLogo, rCloud, collect, alreadyCollect, rComment, rUpload;
    private Spinner business_time_spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);
        changeColor(R.color.status);

        rLogo = (ImageView) findViewById(R.id.rLogo);
        rName = (TextView) findViewById(R.id.rName);
        rStar = (TextView) findViewById(R.id.rStar);
        rAddress = (TextView) findViewById(R.id.rAddress);
        rPhone = (TextView) findViewById(R.id.rPhone);
        rWebsite = (TextView) findViewById(R.id.rWebsite);
        rlabel = (TextView) findViewById(R.id.rlabel);
        rCloud = (ImageView) findViewById(R.id.rCloud);
        goback = (ImageButton) findViewById(R.id.goback);
        map = (ImageButton) findViewById(R.id.map);
        rComment = (ImageView) findViewById(R.id.rComment);
        rUpload = (ImageView) findViewById(R.id.rUpload);

        business_time_spinner = findViewById(R.id.business_time_spinner);


        goback.setOnClickListener(gobackListener);
        map.setOnClickListener(mapListener);
        rComment.setOnClickListener(rCommentListener);
        rUpload.setOnClickListener(rUploadListener);

        collect = (ImageView) findViewById(R.id.collect);
        alreadyCollect = (ImageView) findViewById(R.id.alreadyCollect);
        collect.setOnClickListener(collectListener);
        alreadyCollect.setOnClickListener(alreadyCollectListener);

        currentResId = getIntent().getExtras().get("resName").toString();
        userid = getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("USER","999");
        Connection connection;
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT store_info_id, store_name, total_score, address, phone_number, url, special_label, wordcloud ,business_hour " +
                    "FROM store_info WHERE store_info_id = "+currentResId+"";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()) {
                rName.setText(set.getString(2));
                rStar.setText(set.getString(3));
                rAddress.setText(set.getString(4));
                rPhone.setText(set.getString(5));
                rWebsite.setAutoLinkMask(Linkify.ALL);
                rWebsite.setText(set.getString(6));
                String[] temp = set.getString(7).split(",");
                rlabel.setText(temp[0]);

                if (set.getString(8).equals("")){
                    rCloud.setImageBitmap(null);
                }else {
                    byte[] bytes = Base64.decode(set.getString(8),Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    rCloud.setImageBitmap(bitmap_resize);
                }

                List<String> business_time_list = new ArrayList<>(Arrays.asList(set.getString(9).split(",")));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    business_time_list.sort(Comparator.naturalOrder());
                }
                List<String> business_time = new ArrayList<>();
                business_time.add("點擊查看營業時間");
                for(int i = 0 ; i < business_time_list.size() ; i++){
                    String[] strings = business_time_list.get(i).split(":");
                    String temp_weekday = strings[0];
                    switch (temp_weekday){
                        case "1":
                            temp_weekday = "星期一";
                            break;
                        case "2":
                            temp_weekday = "星期二";
                            break;
                        case "3":
                            temp_weekday = "星期三";
                            break;
                        case "4":
                            temp_weekday = "星期四";
                            break;
                        case "5":
                            temp_weekday = "星期五";
                            break;
                        case "6":
                            temp_weekday = "星期六";
                            break;
                        case "7":
                            temp_weekday = "星期日";
                            break;
                    }
                    String temp_time = strings[1].substring(0,4) + " - " + strings[1].substring(4,8);
                    String temp_business_time = temp_weekday + " ：" + temp_time;
                    business_time.add(temp_business_time);
                }
                ArrayAdapter business_time_adapter = new  ArrayAdapter(this
                        ,android.R.layout.simple_spinner_dropdown_item,business_time);
                business_time_spinner.setAdapter(business_time_adapter);
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT image FROM store_image WHERE store_info_id = "+currentResId+"";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                if (set.getString(1).equals("")){
                    rLogo.setImageBitmap(null);
                }else {
                    byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    rLogo.setImageBitmap(bitmap_resize);
                }
            }

            connection.close();
        }catch (Exception e){
            Log.d("SqlCon2",e.toString());
        }
        List<String> user_like = new ArrayList<>();
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT store_info_id FROM member_collection_id WHERE (member_id =" + userid + ")";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                user_like.add(set.getString(1));
            }
            for (int i=0; i<user_like.size(); i++){
                if(user_like.contains(currentResId)){
                    alreadyCollect.setVisibility(View.VISIBLE);
                    collect.setVisibility(View.INVISIBLE);
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon3",e.toString());
        }
    }

    private ImageButton.OnClickListener gobackListener =
            new ImageButton.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            };

    private View.OnClickListener collectListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alreadyCollect.setVisibility(View.VISIBLE);
                    collect.setVisibility(View.INVISIBLE);

                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "INSERT INTO member_collection_id (member_id, store_info_id, create_time) VALUES ("+userid+", "+currentResId+", getdate())";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon4",e.toString());
                    }
                }
            };

    private View.OnClickListener alreadyCollectListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    collect.setVisibility(View.VISIBLE);
                    alreadyCollect.setVisibility(View.INVISIBLE);

                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "DELETE FROM member_collection_id WHERE (store_info_id = "+currentResId+") and (member_id ="+userid+")";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon5",e.toString());
                    }

                }
            };

    private View.OnClickListener mapListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "SELECT store_name, latitude_longitude FROM store_info WHERE store_info_id = "+currentResId+"";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        while (set.next()){
                            String mapName = set.getString(1);
                            String uriBegin = "geo:"+set.getString(2)+"";
                            String query = ""+set.getString(2)+"("+mapName+")";
                            String encodeQuery =Uri.encode(query);
                            String uriString = ""+uriBegin+"?q="+encodeQuery+"";
                            Uri uri = Uri.parse(uriString);
                            Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                            startActivity(intent);
                        }
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon6",e.toString());
                    }

                }
            };

    private View.OnClickListener rCommentListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String rCurrentResId = currentResId;
                    Intent intent = new Intent(Restaurant.this, Restaurant_Comment.class);
                    intent.putExtra("cResName", rCurrentResId);
                    startActivity(intent);
                }
            };

    private View.OnClickListener rUploadListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String rCurrentResId = currentResId;
                    Intent intent = new Intent(Restaurant.this, Restaurant_Picture_Upload.class);
                    intent.putExtra("cResName", rCurrentResId);
                    startActivity(intent);
                }
            };


    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}
