package com.example.food_project

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SimpleAdapter
import android.widget.Spinner
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_search.*

class Search : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 21) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = this.resources.getColor(R.color.status)
        }

        setContentView(R.layout.activity_search)

        val spinner1 = arrayListOf("距離：由近到遠", "距離：由遠到近", "項目：早餐", "項目：午餐", "項目：下午茶", "項目：晚餐", "項目：宵夜")
        val spinnerAdapter1 = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, spinner1)
        spinner.adapter = spinnerAdapter1

//        val spinner11 = arrayListOf("項目", "早餐", "午餐", "下午茶", "晚餐", "宵夜")
//        val spinnerAdapter11 = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, spinner11)
//        spinner2.adapter = spinnerAdapter11

        searchHome.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        searchNtub.setOnClickListener {
            startActivity(Intent(this, Ntub::class.java))
        }

        searchLoved.setOnClickListener {
            startActivity(Intent(this, Loved::class.java))
        }

        searchAiSearch.setOnClickListener {
            startActivity(Intent(this, AiSearch::class.java))
        }

        searchProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        imageButton.setOnClickListener {
            startActivity(Intent(this, noodle::class.java))
        }

        imageButton18.setOnClickListener {
            startActivity(Intent(this, sushi::class.java))
        }


//        val imgId = arrayListOf(R.drawable.p21, R.drawable.p22, R.drawable.p23, R.drawable.p24)
//        val items = ArrayList<Map<String, Any>>()
//
//        for (i in imgId.indices) {
//            val item = HashMap<String, Any>()
//            item["imgId"] = imgId[i]
//            items.add(item)
//        }
//
//        val adapter = SimpleAdapter(this,
//            items, R.layout.grid_item5, arrayOf("imgId"),
//            intArrayOf(R.id.gridImg5))
//
//        searchGridView.adapter = adapter

        spinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, pos: Int, id: Long) {

            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                TODO("Not yet implemented")
            }
        }

    }
}