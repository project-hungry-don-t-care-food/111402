package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class discuss_detail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discuss_detail);
        changeColor(R.color.status);

        TextView discuss_detail_writer = findViewById(R.id.discuss_detail_writer);
        TextView discuss_detail_create_time = findViewById(R.id.discuss_detail_create_time);
        TextView discuss_detail_title = findViewById(R.id.discuss_detail_title);
        TextView discuss_detail_content = findViewById(R.id.discuss_detail_content);
        TextView discuss_detail_like = findViewById(R.id.discuss_detail_times);

        ImageView discuss_detail_avator = findViewById(R.id.discuss_detail_avator);
        ImageView discuss_detail_image = findViewById(R.id.discuss_detail_image);
        ImageView discuss_detail_press = findViewById(R.id.discuss_detail_press);
        ImageView discuss_detail_unpress = findViewById(R.id.discuss_detail_unpress);

//        從Intent取得資料
        String comment_id = getIntent().getExtras().get("comment_id").toString();
        String member_name = getIntent().getExtras().get("member_name").toString();
        Bitmap member_avator = (Bitmap) getIntent().getParcelableExtra("member_avator");
        String create_time = getIntent().getExtras().get("create_time").toString();
        String title = getIntent().getExtras().get("title").toString().replace("\\n","\n");
        String score = getIntent().getExtras().get("score").toString();
        String content = getIntent().getExtras().get("content").toString().replace("\\n","\n");
        String like_num = getIntent().getExtras().get("like_num").toString();

        discuss_detail_writer.setText(member_name);
        discuss_detail_create_time.setText(create_time);
        discuss_detail_title.setText(title);
        discuss_detail_content.setText(content);
        discuss_detail_like.setText(like_num);
        discuss_detail_avator.setImageBitmap(member_avator);

        Connection connection;
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT image FROM store_local_comment WHERE (local_comment_id = " + comment_id + ")";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                if (set.getString(1).equals("")){
                    discuss_detail_image.setImageBitmap(null);
                }else {
                    byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
//                Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 300, 300, false);
                    discuss_detail_image.setImageBitmap(bitmap);
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

//        判斷使用者是否有按讚
        String userid = getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("USER","-999");
        List<String> user_like = new ArrayList<>();
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT ISNULL(preference, N'') as preference FROM member " +
                    "WHERE (member_id = " + userid + ")";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                String[] temp = set.getString(1).split(",");
                user_like.addAll(Arrays.asList(temp));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon2",e.toString());
        }

        if(user_like.contains(comment_id)){
            discuss_detail_press.setVisibility(View.VISIBLE);
        }else {
            discuss_detail_unpress.setVisibility(View.VISIBLE);
        }

        discuss_detail_press.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                discuss_detail_press.setVisibility(View.INVISIBLE);
                discuss_detail_unpress.setVisibility(View.VISIBLE);

                Connection connection1;
                try {
                    ConSQL c = new ConSQL();
                    connection1 = c.conclass();
                    String sqlstatement = "UPDATE store_local_comment SET like_num = like_num - 1 WHERE (local_comment_id = " + comment_id + ")";
                    Statement smt = connection1.createStatement();
                    int set = smt.executeUpdate(sqlstatement);

                    connection1.close();
                }catch (Exception e){
                    Log.d("SqlCon3",e.toString());
                }

                user_like.remove(comment_id);
                String temp = user_like.toString().replace("[","").replace("]","").replace(" ","");
                try {
                    ConSQL c = new ConSQL();
                    connection1 = c.conclass();
                    String sqlstatement = "UPDATE member SET preference = N'" + temp + "' WHERE (member_id = " + userid +")";
                    Statement smt = connection1.createStatement();
                    int set = smt.executeUpdate(sqlstatement);

                    connection1.close();
                }catch (Exception e){
                    Log.d("SqlCon4",e.toString());
                }
                Toast.makeText(discuss_detail.this, "已取消讚", Toast.LENGTH_SHORT).show();
            }
        });
        discuss_detail_unpress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                discuss_detail_press.setVisibility(View.VISIBLE);
                discuss_detail_unpress.setVisibility(View.INVISIBLE);

                Connection connection1;
                try {
                    ConSQL c = new ConSQL();
                    connection1 = c.conclass();
                    String sqlstatement = "UPDATE store_local_comment SET like_num = like_num + 1 WHERE (local_comment_id = " + comment_id + ")";
                    Statement smt = connection1.createStatement();
                    int set = smt.executeUpdate(sqlstatement);

                    connection1.close();
                }catch (Exception e){
                    Log.d("SqlCon5",e.toString());
                }

                user_like.add(comment_id);
                String temp = user_like.toString().replace("[","").replace("]","").replace(" ","");
                try {
                    ConSQL c = new ConSQL();
                    connection1 = c.conclass();
                    String sqlstatement = "UPDATE member SET preference = N'" + temp + "' WHERE (member_id = " + userid +")";
                    Statement smt = connection1.createStatement();
                    int set = smt.executeUpdate(sqlstatement);

                    connection1.close();
                }catch (Exception e){
                    Log.d("SqlCon6",e.toString());
                }
                Toast.makeText(discuss_detail.this, "已按讚", Toast.LENGTH_SHORT).show();
            }
        });


    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}