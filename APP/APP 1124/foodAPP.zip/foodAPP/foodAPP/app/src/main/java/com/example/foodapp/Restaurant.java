package com.example.foodapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Restaurant extends AppCompatActivity {

    private ImageButton goback, map;
    private String currentResId, userid, getName;
    private TextView rName, rStar, rAddress, rPhone, rWebsite, rlabel;
    private ImageView rLogo, rCloud, collect, alreadyCollect, rComment, rUpload, picBig, picCancel;
    private Spinner business_time_spinner;
    private GridView menupic, rpic, foodpic;
    private Button restaurantClose;
    private androidx.constraintlayout.widget.ConstraintLayout ConstraintLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);
        changeColor(R.color.status);

        rLogo = (ImageView) findViewById(R.id.rLogo);
        rName = (TextView) findViewById(R.id.rName);
        rStar = (TextView) findViewById(R.id.rStar);
        rAddress = (TextView) findViewById(R.id.rAddress);
        rPhone = (TextView) findViewById(R.id.rPhone);
        rWebsite = (TextView) findViewById(R.id.rWebsite);
        rlabel = (TextView) findViewById(R.id.rlabel);
        rCloud = (ImageView) findViewById(R.id.rCloud);
        goback = (ImageButton) findViewById(R.id.goback);
        map = (ImageButton) findViewById(R.id.map);
        rComment = (ImageView) findViewById(R.id.rComment);
        rUpload = (ImageView) findViewById(R.id.rUpload);
        picBig = (ImageView) findViewById(R.id.picBig);
        picCancel = (ImageView) findViewById(R.id.picCancel);
        ConstraintLayout = findViewById(R.id.ConstraintLayout);
        menupic = findViewById(R.id.menupic);
        rpic = findViewById(R.id.rpic);
        foodpic = findViewById(R.id.foodpic);
        restaurantClose = findViewById(R.id.restaurantClose);
        business_time_spinner = findViewById(R.id.business_time_spinner);


        goback.setOnClickListener(gobackListener);
        map.setOnClickListener(mapListener);
        rComment.setOnClickListener(rCommentListener);
        rUpload.setOnClickListener(rUploadListener);

        collect = (ImageView) findViewById(R.id.collect);
        alreadyCollect = (ImageView) findViewById(R.id.alreadyCollect);
        collect.setOnClickListener(collectListener);
        alreadyCollect.setOnClickListener(alreadyCollectListener);

        currentResId = getIntent().getExtras().get("resName").toString();
        userid = getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("USER","-999");
        Connection connection;
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT store_info_id, store_name, total_score, address, phone_number, url, special_label, wordcloud ,business_hour " +
                    "FROM store_info WHERE store_info_id = "+currentResId+"";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()) {
                rName.setText(set.getString(2));
                getName = set.getString(2);
                rStar.setText(set.getString(3));
                rAddress.setText(set.getString(4));
                rPhone.setText(set.getString(5));
                rWebsite.setAutoLinkMask(Linkify.ALL);
                rWebsite.setText(set.getString(6));
                String[] temp = set.getString(7).split(",");
                rlabel.setText(temp[0]);

                if (set.getString(8).equals("")){
                    rCloud.setImageBitmap(null);
                }else {
                    byte[] bytes = Base64.decode(set.getString(8),Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    rCloud.setImageBitmap(bitmap_resize);
                }

                List<String> business_time_list = new ArrayList<>(Arrays.asList(set.getString(9).split(",")));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    business_time_list.sort(Comparator.naturalOrder());
                }
                List<String> business_time = new ArrayList<>();
                business_time.add("點擊查看營業時間");
                for(int i = 0 ; i < business_time_list.size() ; i++){
                    String[] strings = business_time_list.get(i).split(":");
                    String temp_weekday = strings[0];
                    switch (temp_weekday){
                        case "1":
                            temp_weekday = "星期一";
                            break;
                        case "2":
                            temp_weekday = "星期二";
                            break;
                        case "3":
                            temp_weekday = "星期三";
                            break;
                        case "4":
                            temp_weekday = "星期四";
                            break;
                        case "5":
                            temp_weekday = "星期五";
                            break;
                        case "6":
                            temp_weekday = "星期六";
                            break;
                        case "7":
                            temp_weekday = "星期日";
                            break;
                    }
                    String temp_time = strings[1].substring(0,4) + " - " + strings[1].substring(4,8);
                    String temp_business_time = temp_weekday + " ：" + temp_time;
                    business_time.add(temp_business_time);
                }
                ArrayAdapter business_time_adapter = new  ArrayAdapter(this
                        ,android.R.layout.simple_spinner_dropdown_item,business_time);
                business_time_spinner.setAdapter(business_time_adapter);
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT image FROM store_image WHERE (store_info_id = "+ currentResId +") AND (Label = N'3') ";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                if (set.getString(1).equals("")){
                    rLogo.setImageBitmap(null);
                }else {
                    byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    rLogo.setImageBitmap(bitmap_resize);
                }
            }

            connection.close();
        }catch (Exception e){
            Log.d("SqlCon2",e.toString());
        }
        List<String> user_like = new ArrayList<>();
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT store_info_id FROM member_collection_id WHERE (member_id =" + userid + ")";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                user_like.add(set.getString(1));
            }
            for (int i=0; i<user_like.size(); i++){
                if(user_like.contains(currentResId)){
                    alreadyCollect.setVisibility(View.VISIBLE);
                    collect.setVisibility(View.INVISIBLE);
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon3",e.toString());
        }

        List<String> id1 = new ArrayList<String>();
        List<String> id2 = new ArrayList<String>();
        List<String> id3 = new ArrayList<String>();
        List<Bitmap> menu = new ArrayList<Bitmap>();
        List<Bitmap> other = new ArrayList<Bitmap>();
        List<Bitmap> food = new ArrayList<Bitmap>();

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (5) store_image_id, image FROM store_image WHERE (store_info_id = "+ currentResId +") AND (label = N'2') ORDER BY create_time DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id1.add(set.getString(1));
                if (set.getString(2).equals("")){
                    menu.add(null);
                }else {
                    byte[] bytes = Base64.decode(set.getString(2),Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    menu.add(bitmap_resize);
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        pic1 adasport1 = new pic1(this, menu);
        menupic.setAdapter(adasport1);

        menupic.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String picId = id1.get(i);
                Connection connection;
                ConstraintLayout.setVisibility(View.VISIBLE);
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image WHERE store_image_id = "+ picId +"";
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        picBig.setImageBitmap(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon1",e.toString());
                }

            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (5) store_image_id, image FROM store_image WHERE (store_info_id = "+ currentResId +") AND (label = N'1') ORDER BY create_time DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id2.add(set.getString(1));
                if (set.getString(2).equals("")){
                    other.add(null);
                }else {
                    byte[] bytes = Base64.decode(set.getString(2),Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    other.add(bitmap_resize);
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon2",e.toString());
        }

        pic2 adasport2 = new pic2(this, other);
        rpic.setAdapter(adasport2);

        rpic.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String picId = id2.get(i);
                Connection connection;
                ConstraintLayout.setVisibility(View.VISIBLE);
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image WHERE store_image_id = "+ picId +"";
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        picBig.setImageBitmap(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon2",e.toString());
                }
            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (5) store_image_id, image FROM store_image WHERE (store_info_id = "+ currentResId +") AND (label = N'0') ORDER BY create_time DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id3.add(set.getString(1));
                if (set.getString(2).equals("")){
                    food.add(null);
                }else {
                    byte[] bytes = Base64.decode(set.getString(2),Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    food.add(bitmap_resize);
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon3",e.toString());
        }

        pic3 adasport3 = new pic3(this, food);
        foodpic.setAdapter(adasport3);

        foodpic.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String picId = id3.get(i);
                Connection connection;
                ConstraintLayout.setVisibility(View.VISIBLE);
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image WHERE store_image_id = "+ picId +"";
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        picBig.setImageBitmap(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon3",e.toString());
                }
            }
        });

        rCloud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Connection connection;
                ConstraintLayout.setVisibility(View.VISIBLE);
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT wordcloud FROM store_info WHERE store_info_id = "+currentResId+"";
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        picBig.setImageBitmap(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon1",e.toString());
                }
            }
        });

        picCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ConstraintLayout.setVisibility(View.INVISIBLE);
            }
        });

        restaurantClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Restaurant.this); //創建訊息方塊
                builder.setMessage("是否要回報「"+getName+"」已停業？");
                builder.setTitle("確認要回報停業？");
                builder.setPositiveButton("是", new DialogInterface.OnClickListener()  {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(Restaurant.this, "已收到回報，感謝您的回報！", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("否", new DialogInterface.OnClickListener()  {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                builder.create().show();
            }
        });

    }


    private ImageButton.OnClickListener gobackListener =
            new ImageButton.OnClickListener() {
                @Override
                public void onClick(View view) {
                    SharedPreferences pref = getSharedPreferences("user_info", MODE_PRIVATE);
                    pref.edit()
                            .putString("modify_collect", "1")
                            .apply();

                    finish();
                }
            };

    private View.OnClickListener collectListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alreadyCollect.setVisibility(View.VISIBLE);
                    collect.setVisibility(View.INVISIBLE);

                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "INSERT INTO member_collection_id (member_id, store_info_id, create_time) VALUES ("+userid+", "+currentResId+", getdate())";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon4",e.toString());
                    }
                }
            };

    private View.OnClickListener alreadyCollectListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    collect.setVisibility(View.VISIBLE);
                    alreadyCollect.setVisibility(View.INVISIBLE);

                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "DELETE FROM member_collection_id WHERE (store_info_id = "+currentResId+") and (member_id ="+userid+")";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon5",e.toString());
                    }

                }
            };

    private View.OnClickListener mapListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "SELECT store_name, latitude_longitude FROM store_info WHERE store_info_id = "+currentResId+"";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        while (set.next()){
                            String mapName = set.getString(1);
                            String uriBegin = "geo:"+set.getString(2)+"";
                            String query = ""+set.getString(2)+"("+mapName+")";
                            String encodeQuery =Uri.encode(query);
                            String uriString = ""+uriBegin+"?q="+encodeQuery+"";
                            Uri uri = Uri.parse(uriString);
                            Intent intent = new Intent(Intent.ACTION_VIEW,uri);
                            startActivity(intent);
                        }
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon6",e.toString());
                    }

                }
            };

    private View.OnClickListener rCommentListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String rCurrentResId = currentResId;
                    Intent intent = new Intent(Restaurant.this, Restaurant_Comment.class);
                    intent.putExtra("cResName", rCurrentResId);
                    startActivity(intent);
                }
            };

    private View.OnClickListener rUploadListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String rCurrentResId = currentResId;
                    Intent intent = new Intent(Restaurant.this, Restaurant_Picture_Upload.class);
                    intent.putExtra("cResName", rCurrentResId);
                    startActivity(intent);
                }
            };

    public static class pic1 extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        public pic1(Context context, List<Bitmap> menu){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = menu;
        }
        @Override
        public int getCount() {
            return adapter_images.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.restaurantlayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView picture = (ImageView) view.findViewById(R.id.picture);

            picture.setImageBitmap(adapter_images.get(i));

            return view;
        }

    }
    public static class pic2 extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        public pic2(Context context, List<Bitmap> other){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = other;
        }
        @Override
        public int getCount() {
            return adapter_images.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.restaurantlayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView picture = (ImageView) view.findViewById(R.id.picture);

            picture.setImageBitmap(adapter_images.get(i));

            return view;
        }
    }
    public static class pic3 extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        public pic3(Context context, List<Bitmap> food){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = food;
        }
        @Override
        public int getCount() {
            return adapter_images.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.restaurantlayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView picture = (ImageView) view.findViewById(R.id.picture);

            picture.setImageBitmap(adapter_images.get(i));

            return view;
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        Connection connection;
        List<String> id1 = new ArrayList<String>();
        List<String> id2 = new ArrayList<String>();
        List<String> id3 = new ArrayList<String>();
        List<Bitmap> menu = new ArrayList<Bitmap>();
        List<Bitmap> other = new ArrayList<Bitmap>();
        List<Bitmap> food = new ArrayList<Bitmap>();

        String userid = getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("USER","-999");
        String modify_food_upload = getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("modify_food_upload","");
        String modify_other_upload = getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("modify_other_upload","");
        String modify_menu_upload = getSharedPreferences("user_info",MODE_PRIVATE)
                .getString("modify_menu_upload","");

        Log.d("SqlCon83",modify_food_upload);
        Log.d("SqlCon84",modify_other_upload);
        Log.d("SqlCon85",modify_menu_upload);

        if (modify_food_upload.equals("1")){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT TOP (5) store_image_id, image FROM store_image WHERE (store_info_id = "+ currentResId +") AND (label = N'0') ORDER BY create_time DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id3.add(set.getString(1));
                    if (set.getString(2).equals("")){
                        food.add(null);
                    }else {
                        byte[] bytes = Base64.decode(set.getString(2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        food.add(bitmap_resize);
                    }
                }
                connection.close();

            SharedPreferences pref = getSharedPreferences("user_info", MODE_PRIVATE);
                pref.edit()
                        .remove("modify_food_upload")
                        .apply();

            }catch (Exception e){
                Log.d("SqlCon3",e.toString());
            }
            pic3 adasport3 = new pic3(this, food);
            foodpic.setAdapter(adasport3);

            foodpic.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String picId = id3.get(i);
                    Connection connection;
                    ConstraintLayout.setVisibility(View.VISIBLE);
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "SELECT image FROM store_image WHERE store_image_id = "+ picId +"";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        while (set.next()){
                            byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                            Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                            picBig.setImageBitmap(bitmap_resize);
                        }
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon3",e.toString());
                    }
                }
            });
        }

        if (modify_other_upload.equals("1")){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT TOP (5) store_image_id, image FROM store_image WHERE (store_info_id = "+ currentResId +") AND (label = N'1') ORDER BY create_time DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id2.add(set.getString(1));
                    if (set.getString(2).equals("")){
                        other.add(null);
                    }else {
                        byte[] bytes = Base64.decode(set.getString(2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        other.add(bitmap_resize);
                    }
                }
                connection.close();

                SharedPreferences pref = getSharedPreferences("user_info", MODE_PRIVATE);
                pref.edit()
                        .remove("modify_other_upload")
                        .apply();

            }catch (Exception e){
                Log.d("SqlCon2",e.toString());
            }
            pic2 adasport2 = new pic2(this, other);
            rpic.setAdapter(adasport2);

            rpic.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String picId = id2.get(i);
                    Connection connection;
                    ConstraintLayout.setVisibility(View.VISIBLE);
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "SELECT image FROM store_image WHERE store_image_id = "+ picId +"";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        while (set.next()){
                            byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                            Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                            picBig.setImageBitmap(bitmap_resize);
                        }
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon2",e.toString());
                    }
                }
            });
        }

        if (modify_menu_upload.equals("1")){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT TOP (5) store_image_id, image FROM store_image WHERE (store_info_id = "+ currentResId +") AND (label = N'2') ORDER BY create_time DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id1.add(set.getString(1));
                    if (set.getString(2).equals("")){
                        menu.add(null);
                    }else {
                        byte[] bytes = Base64.decode(set.getString(2),Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        menu.add(bitmap_resize);
                    }
                }
                connection.close();

                SharedPreferences pref = getSharedPreferences("user_info", MODE_PRIVATE);
                pref.edit()
                        .remove("modify_menu_upload")
                        .apply();

            }catch (Exception e){
                Log.d("SqlCon1",e.toString());
            }
            pic1 adasport1 = new pic1(this, menu);
            menupic.setAdapter(adasport1);

            menupic.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String picId = id1.get(i);
                    Connection connection;
                    ConstraintLayout.setVisibility(View.VISIBLE);
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "SELECT image FROM store_image WHERE store_image_id = "+ picId +"";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        while (set.next()){
                            byte[] bytes = Base64.decode(set.getString(1),Base64.DEFAULT);
                            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                            Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                            picBig.setImageBitmap(bitmap_resize);
                        }
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon1",e.toString());
                    }

                }
            });
        }
    }


    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}
