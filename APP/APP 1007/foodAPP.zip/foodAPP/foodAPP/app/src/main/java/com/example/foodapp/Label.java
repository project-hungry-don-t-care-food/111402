package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Label extends AppCompatActivity {

    private GridView labelrestaurant;
    private TextView labelText;
    private ImageButton backtohome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_label);

        Connection connection;
        labelrestaurant = (GridView) findViewById(R.id.labelrestaurant);
        labelText = (TextView) findViewById(R.id.labelText);
        backtohome = (ImageButton) findViewById(R.id.backtohome);
        backtohome.setOnClickListener(backtohomeListener);

        //label1
        List<Bitmap> image1 = new ArrayList<Bitmap>();
        List<String> id1 = new ArrayList<String>();
        List<String> name1 = new ArrayList<String>();

        labelText.setText("老店");

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT store_info_id, store_name FROM store_info where special_label like N'%老店%' ";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id1.add(set.getString(1));
                name1.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        for (int count = 0; count < name1.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id1.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 300, 300, false);
                    image1.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon2",e.toString());
            }
        }

        Home.label1View adasport1= new Home.label1View(this, image1, name1);
        labelrestaurant.setAdapter(adasport1);
    }

    private ImageButton.OnClickListener backtohomeListener =
            new ImageButton.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            };
}