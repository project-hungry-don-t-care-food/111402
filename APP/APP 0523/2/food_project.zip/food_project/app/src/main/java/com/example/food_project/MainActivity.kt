package com.example.food_project

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SimpleAdapter
import kotlinx.android.synthetic.main.activity_ai_search.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.mylayout.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 21) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = this.resources.getColor(R.color.status)
        }


        setContentView(R.layout.activity_main)

        homeSearch.setOnClickListener {
            startActivity(Intent(this, Search::class.java))
        }

        homeNtub.setOnClickListener {
            startActivity(Intent(this, Ntub::class.java))
        }

        homeLoved.setOnClickListener {
            startActivity(Intent(this, Loved::class.java))
        }

        homeAiSearch.setOnClickListener {
            startActivity(Intent(this, AiSearch::class.java))
        }

        homeProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        val imgId = arrayListOf(R.drawable.cp, R.drawable.health, R.drawable.fast, R.drawable.fresh)
        val imgId2 = arrayListOf(R.drawable.p11, R.drawable.p13, R.drawable.p15, R.drawable.p17)
        val imgId3 = arrayListOf(R.drawable.p12, R.drawable.p14, R.drawable.p16, R.drawable.p18)
        val name1 = arrayListOf( "合掌村","雙月","肯德基","雙月")
        val name2 = arrayListOf( "阜杭豆漿","巧之味","漢堡王","百八魚場")
        val items = ArrayList<Map<String, Any>>()

        for (i in imgId.indices) {
            val item = HashMap<String, Any>()
            item["imageView"] = imgId[i]
            item["imageButton"] = imgId2[i]
            item["imageButton2"] = imgId3[i]
            item["textView"] = name1[i]
            item["textView2"] = name2[i]
            items.add(item)
        }

        val adapter = SimpleAdapter(this,
            items, R.layout.mylayout, arrayOf("imageView", "imageButton","imageButton2","textView","textView2"),
            intArrayOf(R.id.imageView, R.id.imageButton, R.id.imageButton2, R.id.textView, R.id.textView2))

        listView.adapter = adapter

        recommend.setOnClickListener {
            startActivity(Intent(this, sushi::class.java))
        }
    }
}