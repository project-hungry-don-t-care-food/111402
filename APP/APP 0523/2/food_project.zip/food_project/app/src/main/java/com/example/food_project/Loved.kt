package com.example.food_project

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.SimpleAdapter
import kotlinx.android.synthetic.main.activity_loved.*

class Loved : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 21) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = this.resources.getColor(R.color.status)
        }

        setContentView(R.layout.activity_loved)

        lovedHome.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }

        lovedSearch.setOnClickListener {
            startActivity(Intent(this, Search::class.java))
        }

        lovedNtub.setOnClickListener {
            startActivity(Intent(this, Ntub::class.java))
        }

        lovedAiSearch.setOnClickListener {
            startActivity(Intent(this, AiSearch::class.java))
        }

        lovedProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        val imgId1 = arrayListOf(R.drawable.p41, R.drawable.p43)
        val imgId2 = arrayListOf(R.drawable.p42, R.drawable.p44)
        val imgId11 = arrayListOf(R.drawable.p42, R.drawable.p44)
        val imgId21 = arrayListOf(R.drawable.p43, R.drawable.p41)
        val imgId12 = arrayListOf(R.drawable.p43, R.drawable.p41)
        val imgId22 = arrayListOf(R.drawable.p44, R.drawable.p42)
        val imgId13 = arrayListOf(R.drawable.p44, R.drawable.p42)
        val imgId23 = arrayListOf(R.drawable.p41, R.drawable.p43)
        val imgId3 = arrayListOf(R.drawable.p4loved, R.drawable.p4loved)
        val imgId4 = arrayListOf(R.drawable.p4loved, R.drawable.p4loved)

        val items = ArrayList<Map<String, Any>>()

        for (i in imgId1.indices) {
            val item = HashMap<String, Any>()
            item["imageButton8"] = imgId1[i]
            item["imageButton9"] = imgId2[i]
            item["imageButton10"] = imgId3[i]
            item["imageButton11"] = imgId4[i]
            items.add(item)
        }

        for (i in imgId11.indices) {
            val item = HashMap<String, Any>()
            item["imageButton81"] = imgId11[i]
            item["imageButton91"] = imgId21[i]
            item["imageButton10"] = imgId3[i]
            item["imageButton11"] = imgId4[i]
            items.add(item)
        }

        for (i in imgId12.indices) {
            val item = HashMap<String, Any>()
            item["imageButton82"] = imgId12[i]
            item["imageButton92"] = imgId22[i]
            item["imageButton10"] = imgId3[i]
            item["imageButton11"] = imgId4[i]
            items.add(item)
        }

        for (i in imgId13.indices) {
            val item = HashMap<String, Any>()
            item["imageButton83"] = imgId13[i]
            item["imageButton93"] = imgId23[i]
            item["imageButton10"] = imgId3[i]
            item["imageButton11"] = imgId4[i]
            items.add(item)
        }

        val adapter = SimpleAdapter(this,
            items, R.layout.mylayout4, arrayOf("imageButton8", "imageButton9","imageButton10","imageButton11"),
            intArrayOf(R.id.imageButton8, R.id.imageButton9, R.id.imageButton10, R.id.imageButton11))

        val adapter1 = SimpleAdapter(this,
            items, R.layout.mylayout4, arrayOf("imageButton81", "imageButton91","imageButton10","imageButton11"),
            intArrayOf(R.id.imageButton8, R.id.imageButton9, R.id.imageButton10, R.id.imageButton11))

        val adapter2 = SimpleAdapter(this,
            items, R.layout.mylayout4, arrayOf("imageButton82", "imageButton92","imageButton10","imageButton11"),
            intArrayOf(R.id.imageButton8, R.id.imageButton9, R.id.imageButton10, R.id.imageButton11))

        val adapter3 = SimpleAdapter(this,
            items, R.layout.mylayout4, arrayOf("imageButton83", "imageButton93","imageButton10","imageButton11"),
            intArrayOf(R.id.imageButton8, R.id.imageButton9, R.id.imageButton10, R.id.imageButton11))

        listView4.adapter = adapter
        listView41.adapter = adapter1
        listView42.adapter = adapter2
        listView43.adapter = adapter3

        textView3.setOnClickListener {
            view2.setVisibility(View.VISIBLE)
            view8.setVisibility(View.INVISIBLE)
            view9.setVisibility(View.INVISIBLE)
            view10.setVisibility(View.INVISIBLE)

            listView4.setVisibility(View.VISIBLE)
            listView41.setVisibility(View.INVISIBLE)
            listView42.setVisibility(View.INVISIBLE)
            listView43.setVisibility(View.INVISIBLE)
        }

        textView4.setOnClickListener {
            view8.setVisibility(View.VISIBLE)
            view2.setVisibility(View.INVISIBLE)
            view9.setVisibility(View.INVISIBLE)
            view10.setVisibility(View.INVISIBLE)

            listView41.setVisibility(View.VISIBLE)
            listView4.setVisibility(View.INVISIBLE)
            listView42.setVisibility(View.INVISIBLE)
            listView43.setVisibility(View.INVISIBLE)
        }

        textView5.setOnClickListener {
            view9.setVisibility(View.VISIBLE)
            view2.setVisibility(View.INVISIBLE)
            view8.setVisibility(View.INVISIBLE)
            view10.setVisibility(View.INVISIBLE)

            listView42.setVisibility(View.VISIBLE)
            listView4.setVisibility(View.INVISIBLE)
            listView41.setVisibility(View.INVISIBLE)
            listView43.setVisibility(View.INVISIBLE)
        }

        textView6.setOnClickListener {
            view10.setVisibility(View.VISIBLE)
            view2.setVisibility(View.INVISIBLE)
            view8.setVisibility(View.INVISIBLE)
            view9.setVisibility(View.INVISIBLE)

            listView43.setVisibility(View.VISIBLE)
            listView4.setVisibility(View.INVISIBLE)
            listView41.setVisibility(View.INVISIBLE)
            listView42.setVisibility(View.INVISIBLE)
        }
    }
}