package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Label extends AppCompatActivity {

    private GridView labelrestaurant;
    private TextView labelText;
    private ImageButton backtohome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_label);
        changeColor(R.color.status);

        Connection connection;
        labelrestaurant = (GridView) findViewById(R.id.labelrestaurant);
        labelText = (TextView) findViewById(R.id.labelText);
        backtohome = (ImageButton) findViewById(R.id.backtohome);
        backtohome.setOnClickListener(backtohomeListener);

        Intent intent = this.getIntent();
        String msg = intent.getStringExtra("button");

        List<Bitmap> image = new ArrayList<Bitmap>();
        List<String> id = new ArrayList<String>();
        List<String> name = new ArrayList<String>();

        if (msg.equals("more1")){
            labelText.setText("美味");

            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%美味%') ORDER BY total_score DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id.add(set.getString(1));
                    name.add(set.getString(2));
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon1",e.toString());
            }

            for (int count = 0; count < name.size(); count++){
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        String getSQL = set.getString(1);
                        byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        image.add(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon2",e.toString());
                }
            }
            Home.label1View adasport1 = new Home.label1View(this, image, name);
            labelrestaurant.setAdapter(adasport1);

        }else if (msg.equals("more2")){

            labelText.setText("平價");

            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%平價%') ORDER BY total_score DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id.add(set.getString(1));
                    name.add(set.getString(2));
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon3",e.toString());
            }

            for (int count = 0; count < name.size(); count++){
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        String getSQL = set.getString(1);
                        byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        image.add(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon4",e.toString());
                }
            }

            Home.label2View adasport2 = new Home.label2View(this, image, name);
            labelrestaurant.setAdapter(adasport2);

        }else if (msg.equals("more3")){

            labelText.setText("小吃");

            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%小吃%') ORDER BY total_score DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id.add(set.getString(1));
                    name.add(set.getString(2));
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon5",e.toString());
            }

            for (int count = 0; count < name.size(); count++){
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        String getSQL = set.getString(1);
                        byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        image.add(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon6",e.toString());
                }
            }
            Home.label3View adasport3 = new Home.label3View(this, image, name);
            labelrestaurant.setAdapter(adasport3);

        }else if (msg.equals("more4")){

            labelText.setText("老店");

            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%老店%') ORDER BY total_score DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id.add(set.getString(1));
                    name.add(set.getString(2));
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon7",e.toString());
            }

            for (int count = 0; count < name.size(); count++){
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        String getSQL = set.getString(1);
                        byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        image.add(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon8",e.toString());
                }
            }
            Home.label4View adasport4= new Home.label4View(this, image, name);
            labelrestaurant.setAdapter(adasport4);

        } else if (msg.equals("more5")){

            labelText.setText("聚餐");

            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%聚餐%') ORDER BY total_score DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id.add(set.getString(1));
                    name.add(set.getString(2));
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon9",e.toString());
            }

            for (int count = 0; count < name.size(); count++){
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        String getSQL = set.getString(1);
                        byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        image.add(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon10",e.toString());
                }
            }
            Home.label5View adasport5= new Home.label5View(this, image, name);
            labelrestaurant.setAdapter(adasport5);

        }else if (msg.equals("more6")){

            labelText.setText("不限時");

            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%不限時%') ORDER BY total_score DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id.add(set.getString(1));
                    name.add(set.getString(2));
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon11",e.toString());
            }

            for (int count = 0; count < name.size(); count++){
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        String getSQL = set.getString(1);
                        byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        image.add(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon12",e.toString());
                }
            }
            Home.label6View adasport6 = new Home.label6View(this, image, name);
            labelrestaurant.setAdapter(adasport6);

        }else if (msg.equals("more7")){

            labelText.setText("必比登");

            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%必比登%') ORDER BY total_score DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id.add(set.getString(1));
                    name.add(set.getString(2));
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon13",e.toString());
            }

            for (int count = 0; count < name.size(); count++){
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        String getSQL = set.getString(1);
                        byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        image.add(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon14",e.toString());
                }
            }
            Home.label7View adasport7 = new Home.label7View(this, image, name);
            labelrestaurant.setAdapter(adasport7);

        }else if (msg.equals("more8")){

            labelText.setText("環境");

            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%環境%') ORDER BY total_score DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id.add(set.getString(1));
                    name.add(set.getString(2));
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon15",e.toString());
            }

            for (int count = 0; count < name.size(); count++){
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        String getSQL = set.getString(1);
                        byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        image.add(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon16",e.toString());
                }
            }
            Home.label8View adasport8 = new Home.label8View(this, image, name);
            labelrestaurant.setAdapter(adasport8);

        }else if (msg.equals("more9")){

            labelText.setText("健康");

            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%健康%') ORDER BY total_score DESC";
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    id.add(set.getString(1));
                    name.add(set.getString(2));
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon17",e.toString());
            }

            for (int count = 0; count < name.size(); count++){
                try {
                    ConSQL c = new ConSQL();
                    connection = c.conclass();
                    String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                    Statement smt = connection.createStatement();
                    ResultSet set = smt.executeQuery(sqlstatement);
                    while (set.next()){
                        String getSQL = set.getString(1);
                        byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                        Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                        image.add(bitmap_resize);
                    }
                    connection.close();
                }catch (Exception e){
                    Log.d("SqlCon18",e.toString());
                }
            }
            Home.label9View adasport9 = new Home.label9View(this, image, name);
            labelrestaurant.setAdapter(adasport9);

        }else {}



        labelrestaurant.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResName = id.get(i);
                Intent intent = new Intent(Label.this, Resturant.class);
                intent.putExtra("resName", currentResName);
                startActivity(intent);
            }
        });

    }

    private ImageButton.OnClickListener backtohomeListener =
            new ImageButton.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            };

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}