package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class discuss_detail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discuss_detail);
        changeColor(R.color.status);

        TextView discuss_detail_writer = findViewById(R.id.discuss_detail_writer);
        TextView discuss_detail_create_time = findViewById(R.id.discuss_detail_create_time);
        TextView discuss_detail_title = findViewById(R.id.discuss_detail_title);
        TextView discuss_detail_content = findViewById(R.id.discuss_detail_content);

        ImageView discuss_detail_avator = findViewById(R.id.discuss_detail_avator);
        ImageView discuss_detail_image = findViewById(R.id.discuss_detail_image);

        String comment_id = getIntent().getExtras().get("comment_id").toString();
        String member_name = getIntent().getExtras().get("member_name").toString();
        Bitmap member_avator = (Bitmap) getIntent().getParcelableExtra("member_avator");
        String create_time = getIntent().getExtras().get("create_time").toString();
        String title = getIntent().getExtras().get("title").toString().replace("\\n","\n");
        String score = getIntent().getExtras().get("score").toString();
        String content = getIntent().getExtras().get("content").toString().replace("\\n","\n");
        String like_num = getIntent().getExtras().get("like_num").toString();

        discuss_detail_writer.setText(member_name);
        discuss_detail_create_time.setText(create_time);
        discuss_detail_title.setText(title);
        discuss_detail_content.setText(content);
        discuss_detail_avator.setImageBitmap(member_avator);

    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}