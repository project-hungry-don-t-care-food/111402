package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Label extends AppCompatActivity {

    private GridView labelrestaurant;
    private TextView labelText;
    private ImageButton backtohome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_label);
        changeColor(R.color.status);

        Connection connection;
        labelrestaurant = (GridView) findViewById(R.id.labelrestaurant);
        labelText = (TextView) findViewById(R.id.labelText);
        backtohome = (ImageButton) findViewById(R.id.backtohome);
        backtohome.setOnClickListener(backtohomeListener);

        Intent intent = this.getIntent();
        String msg = intent.getStringExtra("button");

        List<Bitmap> image = new ArrayList<Bitmap>();
        List<String> id = new ArrayList<String>();
        List<String> name = new ArrayList<String>();

        labelText.setText(msg);

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (4) store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%" + msg + "%') ORDER BY total_score DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id.add(set.getString(1));
                name.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        for (int count = 0; count < name.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    image.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon2",e.toString());
            }
        }
        Home.label1View adasport1 = new Home.label1View(this, image, name);
        labelrestaurant.setAdapter(adasport1);

        labelrestaurant.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id.get(i);
                Intent intent = new Intent(Label.this, Resturant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

    }

    private ImageButton.OnClickListener backtohomeListener =
            new ImageButton.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            };

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}