package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Resturant extends AppCompatActivity {

    private ImageButton goback;
    private String currentResId, userid;
    private TextView rName, rStar, rAddress, rPhone, rWebsite;
    private ImageView rLogo, rCloud, collect, alreadyCollect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resturant);
        changeColor(R.color.status);

        rLogo = (ImageView) findViewById(R.id.rLogo);
        rName = (TextView) findViewById(R.id.rName);
        rStar = (TextView) findViewById(R.id.rStar);
        rAddress = (TextView) findViewById(R.id.rAddress);
        rPhone = (TextView) findViewById(R.id.rPhone);
        rWebsite = (TextView) findViewById(R.id.rWebsite);
        rCloud = (ImageView) findViewById(R.id.rCloud);
        goback = (ImageButton) findViewById(R.id.goback);
        goback.setOnClickListener(gobackListener);

        collect = (ImageView) findViewById(R.id.collect);
        alreadyCollect = (ImageView) findViewById(R.id.alreadyCollect);
        collect.setOnClickListener(collectListener);
        alreadyCollect.setOnClickListener(alreadyCollectListener);

        currentResId = getIntent().getExtras().get("resName").toString();
        userid = getSharedPreferences("test",MODE_PRIVATE)
                .getString("USER","999");
        Connection connection;
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();

            String sqlstatement = "SELECT store_info_id, store_name, total_score, address, phone_number, url, wordcloud " +
                    "FROM store_info WHERE store_info_id = "+currentResId+"";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()) {
                rName.setText(set.getString(2));
                rStar.setText(set.getString(3));
                rAddress.setText(set.getString(4));
                rPhone.setText(set.getString(5));
                rWebsite.setAutoLinkMask(Linkify.ALL);
                rWebsite.setText(set.getString(6));
                String getSQL = set.getString(7);
                byte[] bytes = Base64.decode(getSQL, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                rCloud.setImageBitmap(bitmap_resize);
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT image FROM store_image where store_info_id = "+currentResId+"";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                String getSQL = set.getString(1);
                byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                rLogo.setImageBitmap(bitmap_resize);
            }

            connection.close();
        }catch (Exception e){
            Log.d("SqlCon2",e.toString());
        }
        List<String> user_like = new ArrayList<>();
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT store_info_id FROM member_collection_id WHERE (member_id =" + userid + ")";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                user_like.add(set.getString(1));
            }
            for (int i=0; i<user_like.size(); i++){
                if(user_like.contains(currentResId)){
                    alreadyCollect.setVisibility(View.VISIBLE);
                    collect.setVisibility(View.INVISIBLE);
                }
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon3",e.toString());
        }
    }

    private ImageButton.OnClickListener gobackListener =
            new ImageButton.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            };

    private View.OnClickListener collectListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    alreadyCollect.setVisibility(View.VISIBLE);
                    collect.setVisibility(View.INVISIBLE);

                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "INSERT INTO member_collection_id (member_id, store_info_id) VALUES ('"+userid+"','"+currentResId+"')";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon1",e.toString());
                    }
                }
            };

    private View.OnClickListener alreadyCollectListener=
            new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    collect.setVisibility(View.VISIBLE);
                    alreadyCollect.setVisibility(View.INVISIBLE);

                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "DELETE FROM member_collection_id WHERE store_info_id = "+currentResId+"";
                        Statement smt = connection.createStatement();
                        ResultSet set = smt.executeQuery(sqlstatement);
                        connection.close();
                    }catch (Exception e){
                        Log.d("SqlCon1",e.toString());
                    }

                }
            };



    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}
