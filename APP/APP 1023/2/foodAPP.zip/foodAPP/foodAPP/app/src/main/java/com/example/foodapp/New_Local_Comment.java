package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.NumberPicker;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;

public class New_Local_Comment extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_local_comment);
        changeColor(R.color.status);

        String store_info_id = getIntent().getExtras().get("res_id").toString();
        String store_info_name = getIntent().getExtras().get("res_name").toString();

        TextView new_comment_store_name = findViewById(R.id.new_comment_store_name);
        EditText new_comment_input_title = findViewById(R.id.new_comment_input_title);
        NumberPicker new_comment_input_score = findViewById(R.id.new_comment_input_score);
        EditText new_comment_input_content = findViewById(R.id.new_comment_input_content);
        ImageView new_comment_input_image = findViewById(R.id.new_comment_input_image);
        Button new_comment_button_commit = findViewById(R.id.new_comment_button_commit);
        Button new_comment_button_cancel = findViewById(R.id.new_comment_button_cancel);

        new_comment_store_name.setText("店家：" + store_info_name);

        new_comment_input_score.setValue(0);
        new_comment_input_score.setMaxValue(5);
        new_comment_input_score.setMinValue(0);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            new_comment_input_score.setTextSize(45);
            new_comment_input_score.setWrapSelectorWheel(false);
        }

        new_comment_button_commit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String create_time = date.format(new Date());
                String title = new_comment_input_title.getText().toString();
                String member_id = getSharedPreferences("test",MODE_PRIVATE)
                        .getString("USER","999");
                String score = String.valueOf(new_comment_input_score.getValue());
                String content = new_comment_input_content.getText().toString().replace("\n","\\n");
                String like_num = "0";

                String sqlstatement = "INSERT INTO store_local_comment (store_info_id, create_time, title, member_id, score, [content], like_num) " +
                        "OUTPUT Inserted.local_comment_id " +
                        "VALUES (" + store_info_id + ", CONVERT(DATETIME, '" + create_time + "', 102), " +
                        "N'" + title + "', " + member_id + ", " + score + ", N'" + content + "', " + like_num + ")";

                new_comment_input_content.setText(sqlstatement);
//                Connection connection;
//                try {
//                    ConSQL c = new ConSQL();
//                    connection = c.conclass();
//                    String sqlstatement = "INSERT INTO store_local_comment (store_info_id, create_time, title, member_id, score, [content], like_num) " +
//                            "OUTPUT Inserted.local_comment_id " +
//                            "VALUES (73, CONVERT(DATETIME, '2022-10-05 10:50:00', 102), N'test', 2, 1, N'fjieoapjfiods;a', 50)";
//                    Statement smt = connection.createStatement();
//                    int set = smt.executeUpdate(sqlstatement);
//
//                    connection.close();
//                }catch (Exception e){
//                    Log.d("SqlCon1",e.toString());
//                }
            }
        });



    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}