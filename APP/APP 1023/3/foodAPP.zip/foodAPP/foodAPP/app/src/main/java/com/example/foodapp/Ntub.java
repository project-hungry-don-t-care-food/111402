package com.example.foodapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Ntub#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Ntub extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;


    public Ntub() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Ntub.
     */
    // TODO: Rename and change types and number of parameters
    public static Ntub newInstance(String param1, String param2) {
        Ntub fragment = new Ntub();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_ntub, container, false);

        ImageView logo = (ImageView) view.findViewById(R.id.logo);
        TextView name = (TextView) view.findViewById(R.id.name);
        TextView address = (TextView) view.findViewById(R.id.address);
        ListView lst = (ListView) view.findViewById(R.id.lstNtub);

        List<Bitmap> images = new ArrayList<Bitmap>();
        List<String> id = new ArrayList<String>();
        List<String> names = new ArrayList<String>();
        List<String> adds = new ArrayList<String>();

        Connection connection;
        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT store_info_id, store_name, address FROM store_info where store_info_id <= 11";
//            String sqlstatement = "SELECT store_info_id, store_name, address FROM store_info where is_appointed_store = 1";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id.add(set.getString(1));
                names.add(set.getString(2));
                adds.add(set.getString(3));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        for (int count = 0; count < names.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    images.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon2",e.toString());
            }
        }

        ntubListview adasports= new ntubListview(getContext(), images, names, adds);
        lst.setAdapter(adasports);

        lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        return view;
    }

    public static class ntubListview extends BaseAdapter{
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        private final List<String> adapter_adds;
        public ntubListview(Context context, List<Bitmap> images, List<String> names, List<String> adds){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = images;
            adapter_names = names;
            adapter_adds = adds;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.ntublayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.logo);
            TextView name = (TextView) view.findViewById(R.id.name);
            TextView address = (TextView) view.findViewById(R.id.address);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));
            address.setText(adapter_adds.get(i));

            return view;
        }
    }
}