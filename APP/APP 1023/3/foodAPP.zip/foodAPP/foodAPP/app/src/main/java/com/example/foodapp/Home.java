package com.example.foodapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Home#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Home extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public Home() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Home.
     */
    // TODO: Rename and change types and number of parameters
    public static Home newInstance(String param1, String param2) {
        Home fragment = new Home();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_home, container, false);
        
//        IntializeFields();

        Button more1 = (Button) view.findViewById(R.id.more1);
        Button more2 = (Button) view.findViewById(R.id.more2);
        Button more3 = (Button) view.findViewById(R.id.more3);
        Button more4 = (Button) view.findViewById(R.id.more4);
        Button more5 = (Button) view.findViewById(R.id.more5);
        Button more6 = (Button) view.findViewById(R.id.more6);
        Button more7 = (Button) view.findViewById(R.id.more7);
        Button more8 = (Button) view.findViewById(R.id.more8);
        Button more9 = (Button) view.findViewById(R.id.more9);

        GridView label1 = (GridView) view.findViewById(R.id.label1);
        GridView label2 = (GridView) view.findViewById(R.id.label2);
        GridView label3 = (GridView) view.findViewById(R.id.label3);
        GridView label4 = (GridView) view.findViewById(R.id.label4);
        GridView label5 = (GridView) view.findViewById(R.id.label5);
        GridView label6 = (GridView) view.findViewById(R.id.label6);
        GridView label7 = (GridView) view.findViewById(R.id.label7);
        GridView label8 = (GridView) view.findViewById(R.id.label8);
        GridView label9 = (GridView) view.findViewById(R.id.label9);

        Connection connection;

        //label1
        List<Bitmap> image1 = new ArrayList<Bitmap>();
        List<String> id1 = new ArrayList<String>();
        List<String> name1 = new ArrayList<String>();

        TextView labelText1 = (TextView) view.findViewById(R.id.labelText1);
        labelText1.setText("美味");

        more1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent();
                intent.putExtra("button", "美味");
                intent.setClass(getActivity(),Label.class);
                startActivity(intent);
            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (2) store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%美味%') ORDER BY total_score DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id1.add(set.getString(1));
                name1.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon1",e.toString());
        }

        for (int count = 0; count < name1.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id1.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    image1.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon2",e.toString());
            }
        }

        label1View adasport1 = new label1View(getContext(), image1, name1);
        label1.setAdapter(adasport1);

        label1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id1.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        //label2
        List<Bitmap> image2 = new ArrayList<Bitmap>();
        List<String> id2 = new ArrayList<String>();
        List<String> name2 = new ArrayList<String>();

        TextView labelText2 = (TextView) view.findViewById(R.id.labelText2);
        labelText2.setText("平價");

        more2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent();
                intent.putExtra("button", "平價");
                intent.setClass(getActivity(),Label.class);
                startActivity(intent);
            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (2) store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%平價%') ORDER BY total_score DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id2.add(set.getString(1));
                name2.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon3",e.toString());
        }

        for (int count = 0; count < name2.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id2.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    image2.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon4",e.toString());
            }
        }

        label2View adasport2 = new label2View(getContext(), image2, name2);
        label2.setAdapter(adasport2);

        label2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id2.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        //label3
        List<Bitmap> image3 = new ArrayList<Bitmap>();
        List<String> id3 = new ArrayList<String>();
        List<String> name3 = new ArrayList<String>();

        TextView labelText3 = (TextView) view.findViewById(R.id.labelText3);
        labelText3.setText("小吃");

        more3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent();
                intent.putExtra("button", "小吃");
                intent.setClass(getActivity(),Label.class);
                startActivity(intent);
            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (2) store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%小吃%') ORDER BY total_score DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id3.add(set.getString(1));
                name3.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon5",e.toString());
        }

        for (int count = 0; count < name3.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id3.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    image3.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon6",e.toString());
            }
        }

        label3View adasport3 = new label3View(getContext(), image3, name3);
        label3.setAdapter(adasport3);

        label3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id3.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        //label4
        List<Bitmap> image4 = new ArrayList<Bitmap>();
        List<String> id4 = new ArrayList<String>();
        List<String> name4 = new ArrayList<String>();

        TextView labelText4 = (TextView) view.findViewById(R.id.labelText4);
        labelText4.setText("老店");

        more4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent();
                intent.putExtra("button", "老店");
                intent.setClass(getActivity(),Label.class);
                startActivity(intent);
            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (2) store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%老店%') ORDER BY total_score DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id4.add(set.getString(1));
                name4.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon7",e.toString());
        }

        for (int count = 0; count < name4.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id4.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    image4.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon8",e.toString());
            }
        }

        label4View adasport4 = new label4View(getContext(), image4, name4);
        label4.setAdapter(adasport4);

        label4.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id4.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        //label5
        List<Bitmap> image5 = new ArrayList<Bitmap>();
        List<String> id5 = new ArrayList<String>();
        List<String> name5 = new ArrayList<String>();

        TextView labelText5 = (TextView) view.findViewById(R.id.labelText5);
        labelText5.setText("聚餐");

        more5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent();
                intent.putExtra("button", "聚餐");
                intent.setClass(getActivity(),Label.class);
                startActivity(intent);
            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (2) store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%聚餐%') ORDER BY total_score DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id5.add(set.getString(1));
                name5.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon9",e.toString());
        }

        for (int count = 0; count < name5.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id5.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    image5.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon10",e.toString());
            }
        }

        label5View adasport5 = new label5View(getContext(), image5, name5);
        label5.setAdapter(adasport5);

        label5.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id5.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        //label6
        List<Bitmap> image6 = new ArrayList<Bitmap>();
        List<String> id6 = new ArrayList<String>();
        List<String> name6 = new ArrayList<String>();

        TextView labelText6 = (TextView) view.findViewById(R.id.labelText6);
        labelText6.setText("不限時");

        more6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent();
                intent.putExtra("button", "不限時");
                intent.setClass(getActivity(),Label.class);
                startActivity(intent);
            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (2) store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%不限時%') ORDER BY total_score DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id6.add(set.getString(1));
                name6.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon11",e.toString());
        }

        for (int count = 0; count < name6.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id6.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    image6.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon12",e.toString());
            }
        }

        label6View adasport6 = new label6View(getContext(), image6, name6);
        label6.setAdapter(adasport6);

        label6.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id6.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        //label7
        List<Bitmap> image7 = new ArrayList<Bitmap>();
        List<String> id7 = new ArrayList<String>();
        List<String> name7 = new ArrayList<String>();

        TextView labelText7 = (TextView) view.findViewById(R.id.labelText7);
        labelText7.setText("必比登");

        more7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent();
                intent.putExtra("button", "必比登");
                intent.setClass(getActivity(),Label.class);
                startActivity(intent);
            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (2) store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%必比登%') ORDER BY total_score DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id7.add(set.getString(1));
                name7.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon13",e.toString());
        }

        for (int count = 0; count < name7.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id7.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    image7.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon14",e.toString());
            }
        }

        label7View adasport7 = new label7View(getContext(), image7, name7);
        label7.setAdapter(adasport7);

        label7.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id7.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        //label8
        List<Bitmap> image8 = new ArrayList<Bitmap>();
        List<String> id8 = new ArrayList<String>();
        List<String> name8 = new ArrayList<String>();

        TextView labelText8 = (TextView) view.findViewById(R.id.labelText8);
        labelText8.setText("環境");

        more8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent();
                intent.putExtra("button", "環境");
                intent.setClass(getActivity(),Label.class);
                startActivity(intent);
            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (2) store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%環境%') ORDER BY total_score DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id8.add(set.getString(1));
                name8.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon15",e.toString());
        }

        for (int count = 0; count < name8.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id8.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    image8.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon16",e.toString());
            }
        }

        label8View adasport8 = new label8View(getContext(), image8, name8);
        label8.setAdapter(adasport8);

        label8.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId = id8.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        //label9
        List<Bitmap> image9 = new ArrayList<Bitmap>();
        List<String> id9 = new ArrayList<String>();
        List<String> name9 = new ArrayList<String>();

        TextView labelText9 = (TextView) view.findViewById(R.id.labelText9);
        labelText9.setText("健康");

        more9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent();
                intent.putExtra("button", "健康");
                intent.setClass(getActivity(),Label.class);
                startActivity(intent);
            }
        });

        try {
            ConSQL c = new ConSQL();
            connection = c.conclass();
            String sqlstatement = "SELECT TOP (2) store_info_id, store_name FROM store_info WHERE (total_score <> 999) AND (special_label LIKE N'%健康%') ORDER BY total_score DESC";
            Statement smt = connection.createStatement();
            ResultSet set = smt.executeQuery(sqlstatement);
            while (set.next()){
                id9.add(set.getString(1));
                name9.add(set.getString(2));
            }
            connection.close();
        }catch (Exception e){
            Log.d("SqlCon17",e.toString());
        }

        for (int count = 0; count < name9.size(); count++){
            try {
                ConSQL c = new ConSQL();
                connection = c.conclass();
                String sqlstatement = "SELECT image FROM store_image where store_info_id = " + id9.get(count);
                Statement smt = connection.createStatement();
                ResultSet set = smt.executeQuery(sqlstatement);
                while (set.next()){
                    String getSQL = set.getString(1);
                    byte[] bytes = Base64.decode(getSQL,Base64.DEFAULT);
                    Bitmap bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.length);
                    Bitmap bitmap_resize = Bitmap.createScaledBitmap(bitmap, 500, 500, false);
                    image9.add(bitmap_resize);
                }
                connection.close();
            }catch (Exception e){
                Log.d("SqlCon18",e.toString());
            }
        }

        label9View adasport9 = new label9View(getContext(), image9, name9);
        label9.setAdapter(adasport9);

        label9.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String currentResId= id9.get(i);
                Intent intent = new Intent(getContext(), Restaurant.class);
                intent.putExtra("resName", currentResId);
                startActivity(intent);
            }
        });

        return view;
    }

    public static class label1View extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        public label1View(Context context, List<Bitmap> image, List<String> name){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = image;
            adapter_names = name;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.homelabellayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.labelImg);
            TextView name = (TextView) view.findViewById(R.id.labelTxt);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));

            return view;
        }
    }

    public static class label2View extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        public label2View(Context context, List<Bitmap> image, List<String> name){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = image;
            adapter_names = name;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.homelabellayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.labelImg);
            TextView name = (TextView) view.findViewById(R.id.labelTxt);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));

            return view;
        }
    }

    public static class label3View extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        public label3View(Context context, List<Bitmap> image, List<String> name){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = image;
            adapter_names = name;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.homelabellayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.labelImg);
            TextView name = (TextView) view.findViewById(R.id.labelTxt);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));

            return view;
        }
    }

    public static class label4View extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        public label4View(Context context, List<Bitmap> image, List<String> name){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = image;
            adapter_names = name;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.homelabellayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.labelImg);
            TextView name = (TextView) view.findViewById(R.id.labelTxt);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));

            return view;
        }
    }

    public static class label5View extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        public label5View(Context context, List<Bitmap> image, List<String> name){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = image;
            adapter_names = name;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.homelabellayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.labelImg);
            TextView name = (TextView) view.findViewById(R.id.labelTxt);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));

            return view;
        }
    }

    public static class label6View extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        public label6View(Context context, List<Bitmap> image, List<String> name){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = image;
            adapter_names = name;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.homelabellayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.labelImg);
            TextView name = (TextView) view.findViewById(R.id.labelTxt);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));

            return view;
        }
    }

    public static class label7View extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        public label7View(Context context, List<Bitmap> image, List<String> name){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = image;
            adapter_names = name;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.homelabellayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.labelImg);
            TextView name = (TextView) view.findViewById(R.id.labelTxt);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));

            return view;
        }
    }

    public static class label8View extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        public label8View(Context context, List<Bitmap> image, List<String> name){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = image;
            adapter_names = name;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.homelabellayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.labelImg);
            TextView name = (TextView) view.findViewById(R.id.labelTxt);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));

            return view;
        }
    }

    public static class label9View extends BaseAdapter {
        private final LayoutInflater listlayoutInflater;
        private final List<Bitmap> adapter_images;
        private final List<String> adapter_names;
        public label9View(Context context, List<Bitmap> image, List<String> name){
            listlayoutInflater = LayoutInflater.from(context);
            adapter_images = image;
            adapter_names = name;
        }
        @Override
        public int getCount() {
            return adapter_names.size();
        }

        @Override
        public Object getItem(int i) {
            return i;
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint({"ViewHolder", "InflateParams"})
        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            view = listlayoutInflater.inflate(R.layout.homelabellayout,null);

            //設定自訂樣板上物件對應的資料。
            ImageView logo = (ImageView) view.findViewById(R.id.labelImg);
            TextView name = (TextView) view.findViewById(R.id.labelTxt);

            logo.setImageBitmap(adapter_images.get(i));
            name.setText(adapter_names.get(i));

            return view;
        }
    }
}