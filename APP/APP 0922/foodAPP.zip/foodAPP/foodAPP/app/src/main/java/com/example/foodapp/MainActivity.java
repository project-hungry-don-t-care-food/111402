package com.example.foodapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.opengl.Visibility;
import android.os.Build;
import android.os.Bundle;
import android.text.style.LineHeightSpan;
import android.view.View;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import java.sql.Connection;

public class MainActivity extends AppCompatActivity {

    private ImageButton whome, bhome, wsearch, bsearch, wntub, bntub, wloved, bloved, wdiscuss, bdiscuss, wprofile, bprofile;
    private Home home;
    private Search search;
    private Ntub ntub;
    private Loved loved;
    private Discuss discuss;
    private Profile profile;

    private Connection connection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        changeColor(R.color.status);

        whome = (ImageButton) findViewById(R.id.whome);
        bhome = (ImageButton) findViewById(R.id.bhome);
        wsearch = (ImageButton) findViewById(R.id.wsearch);
        bsearch = (ImageButton) findViewById(R.id.bsearch);
        wntub =(ImageButton) findViewById(R.id.wntub);
        bntub =(ImageButton) findViewById(R.id.bntub);
        wloved =(ImageButton) findViewById(R.id.wloved);
        bloved =(ImageButton) findViewById(R.id.bloved);
        wdiscuss =(ImageButton) findViewById(R.id.wdiscuss);
        bdiscuss =(ImageButton) findViewById(R.id.bdiscuss);
        wprofile =(ImageButton) findViewById(R.id.wprofile);
        bprofile =(ImageButton) findViewById(R.id.bprofile);

        whome.setOnClickListener(whomeListener);
        wsearch.setOnClickListener(wsearchListener);
        wntub.setOnClickListener(wntubListener);
        wloved.setOnClickListener(wlovedListener);
        wdiscuss.setOnClickListener(wdiscussListener);
        wprofile.setOnClickListener(wprofileListener);

        home = new Home();
        search = new Search();
        ntub = new Ntub();
        loved = new Loved();
        discuss = new Discuss();
        profile = new Profile();

        getSupportFragmentManager().beginTransaction()
                .add(R.id.fragment_container, home)
                .add(R.id.fragment_container, search)
                .add(R.id.fragment_container, ntub)
                .add(R.id.fragment_container, loved)
                .add(R.id.fragment_container, discuss)
                .add(R.id.fragment_container, profile)
                .hide(search).hide(ntub).hide(loved).hide(discuss).hide(profile)
                .commit();
    }

    private Button.OnClickListener whomeListener =
            new Button.OnClickListener(){
                @Override
                public void onClick(View v){
                    whome.setVisibility(View.INVISIBLE);
                    bhome.setVisibility(View.VISIBLE);
                    wsearch.setVisibility(View.VISIBLE);
                    bsearch.setVisibility(View.INVISIBLE);
                    wntub.setVisibility(View.VISIBLE);
                    bntub.setVisibility(View.INVISIBLE);
                    wloved.setVisibility(View.VISIBLE);
                    bloved.setVisibility(View.INVISIBLE);
                    wdiscuss.setVisibility(View.VISIBLE);
                    bdiscuss.setVisibility(View.INVISIBLE);
                    wprofile.setVisibility(View.VISIBLE);
                    bprofile.setVisibility(View.INVISIBLE);

                    getSupportFragmentManager().beginTransaction()
                            .show(home)
                            .hide(search).hide(ntub).hide(loved).hide(discuss).hide(profile)
                            .commit();
                }
            };


    private Button.OnClickListener wsearchListener =
            new Button.OnClickListener(){
                @Override
                public void onClick(View v){
                    whome.setVisibility(View.VISIBLE);
                    bhome.setVisibility(View.INVISIBLE);
                    wsearch.setVisibility(View.INVISIBLE);
                    bsearch.setVisibility(View.VISIBLE);
                    wntub.setVisibility(View.VISIBLE);
                    bntub.setVisibility(View.INVISIBLE);
                    wloved.setVisibility(View.VISIBLE);
                    bloved.setVisibility(View.INVISIBLE);
                    wdiscuss.setVisibility(View.VISIBLE);
                    bdiscuss.setVisibility(View.INVISIBLE);
                    wprofile.setVisibility(View.VISIBLE);
                    bprofile.setVisibility(View.INVISIBLE);

                    getSupportFragmentManager().beginTransaction()
                            .show(search)
                            .hide(home).hide(ntub).hide(loved).hide(discuss).hide(profile)
                            .commit();
                }
            };

    private Button.OnClickListener wntubListener =
            new Button.OnClickListener(){
                @Override
                public void onClick(View v){
                    whome.setVisibility(View.VISIBLE);
                    bhome.setVisibility(View.INVISIBLE);
                    wsearch.setVisibility(View.VISIBLE);
                    bsearch.setVisibility(View.INVISIBLE);
                    wntub.setVisibility(View.INVISIBLE);
                    bntub.setVisibility(View.VISIBLE);
                    wloved.setVisibility(View.VISIBLE);
                    bloved.setVisibility(View.INVISIBLE);
                    wdiscuss.setVisibility(View.VISIBLE);
                    bdiscuss.setVisibility(View.INVISIBLE);
                    wprofile.setVisibility(View.VISIBLE);
                    bprofile.setVisibility(View.INVISIBLE);

                    getSupportFragmentManager().beginTransaction()
                            .show(ntub)
                            .hide(home).hide(search).hide(loved).hide(discuss).hide(profile)
                            .commit();
                }
            };

    private Button.OnClickListener wlovedListener =
            new Button.OnClickListener(){
                @Override
                public void onClick(View v){
                    whome.setVisibility(View.VISIBLE);
                    bhome.setVisibility(View.INVISIBLE);
                    wsearch.setVisibility(View.VISIBLE);
                    bsearch.setVisibility(View.INVISIBLE);
                    wntub.setVisibility(View.VISIBLE);
                    bntub.setVisibility(View.INVISIBLE);
                    wloved.setVisibility(View.INVISIBLE);
                    bloved.setVisibility(View.VISIBLE);
                    wdiscuss.setVisibility(View.VISIBLE);
                    bdiscuss.setVisibility(View.INVISIBLE);
                    wprofile.setVisibility(View.VISIBLE);
                    bprofile.setVisibility(View.INVISIBLE);

                    getSupportFragmentManager().beginTransaction()
                            .show(loved)
                            .hide(home).hide(search).hide(ntub).hide(discuss).hide(profile)
                            .commit();
                }
            };

    private Button.OnClickListener wdiscussListener =
            new Button.OnClickListener(){
                @Override
                public void onClick(View v){
                    whome.setVisibility(View.VISIBLE);
                    bhome.setVisibility(View.INVISIBLE);
                    wsearch.setVisibility(View.VISIBLE);
                    bsearch.setVisibility(View.INVISIBLE);
                    wntub.setVisibility(View.VISIBLE);
                    bntub.setVisibility(View.INVISIBLE);
                    wloved.setVisibility(View.VISIBLE);
                    bloved.setVisibility(View.INVISIBLE);
                    wdiscuss.setVisibility(View.INVISIBLE);
                    bdiscuss.setVisibility(View.VISIBLE);
                    wprofile.setVisibility(View.VISIBLE);
                    bprofile.setVisibility(View.INVISIBLE);

                    getSupportFragmentManager().beginTransaction()
                            .show(discuss)
                            .hide(home).hide(search).hide(ntub).hide(loved).hide(profile)
                            .commit();
                }
            };

    private Button.OnClickListener wprofileListener =
            new Button.OnClickListener(){
                @Override
                public void onClick(View v){
                    whome.setVisibility(View.VISIBLE);
                    bhome.setVisibility(View.INVISIBLE);
                    wsearch.setVisibility(View.VISIBLE);
                    bsearch.setVisibility(View.INVISIBLE);
                    wntub.setVisibility(View.VISIBLE);
                    bntub.setVisibility(View.INVISIBLE);
                    wloved.setVisibility(View.VISIBLE);
                    bloved.setVisibility(View.INVISIBLE);
                    wdiscuss.setVisibility(View.VISIBLE);
                    bdiscuss.setVisibility(View.INVISIBLE);
                    wprofile.setVisibility(View.INVISIBLE);
                    bprofile.setVisibility(View.VISIBLE);

                    getSupportFragmentManager().beginTransaction()
                            .show(profile)
                            .hide(home).hide(search).hide(ntub).hide(loved).hide(discuss)
                            .commit();
                }
            };

//    private View.OnClickListener

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}