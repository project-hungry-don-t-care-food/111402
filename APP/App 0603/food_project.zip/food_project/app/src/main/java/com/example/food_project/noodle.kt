package com.example.food_project

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import android.widget.SimpleAdapter
import kotlinx.android.synthetic.main.activity_noodle.*
import kotlinx.android.synthetic.main.activity_sushi.*

class noodle : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_noodle)

        if (Build.VERSION.SDK_INT >= 21) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
            window.statusBarColor = this.resources.getColor(R.color.status)
        }

        setContentView(R.layout.activity_noodle)

        val txt = arrayListOf("店家菜單", "環境圖片", "文字雲")
        val imgId = arrayListOf(R.drawable.noodlemenu, R.drawable.noodle, R.drawable.noodlecloud)
        val imgId2 = arrayListOf(R.drawable.p722, R.drawable.p722, "")

        val items = ArrayList<Map<String, Any>>()

        for (i in imgId.indices) {
            val item = HashMap<String, Any>()
            item["textView18"] = txt[i]
            item["imageView19"] = imgId[i]
            item["imageButton17"] = imgId2[i]
            items.add(item)
        }

        val adapter = SimpleAdapter(
            this,
            items, R.layout.mylayout5, arrayOf("textView18", "imageView19", "imageButton17"),
            intArrayOf(R.id.textView18, R.id.imageView19, R.id.imageButton17)
        )

        listView5noodle.adapter = adapter

        imageButton12noodle.setOnClickListener {
            finish();
        }

        imageButton15noodle.setOnClickListener {
            val label = "東京油組総本店"
            val uriBegin = "geo:25.04798894070918, 121.52551531364796"
            val query = "25.04798894070918, 121.52551531364796($label)"
            val encodedQuery = Uri.encode(query)
            val uriString = "$uriBegin?q=$encodedQuery"
            val uri = Uri.parse(uriString)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }
    }
}
