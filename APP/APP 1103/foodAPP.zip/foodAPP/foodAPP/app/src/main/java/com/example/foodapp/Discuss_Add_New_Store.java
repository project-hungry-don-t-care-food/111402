package com.example.foodapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class Discuss_Add_New_Store extends AppCompatActivity {

    private static final int IMAGE_REQUEST_CODE = 0;
    EditText new_store_input_store_name;
    EditText new_store_input_phonenumber;
    EditText new_store_input_address;
    Button new_store_button_button_upload_image;
    ImageView new_store_button_input_image;
    Button new_store_button_button_cancel;
    Button new_store_button_button_commit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discuss_add_new_store);
        changeColor(R.color.status);

        new_store_input_store_name = findViewById(R.id.new_store_input_store_name);
        new_store_input_phonenumber = findViewById(R.id.new_store_input_phonenumber);
        new_store_input_address = findViewById(R.id.new_store_input_address);
        new_store_button_button_upload_image = findViewById(R.id.new_store_button_button_upload_image);
        new_store_button_input_image = findViewById(R.id.new_store_button_input_image);
        new_store_button_button_cancel = findViewById(R.id.new_store_button_button_cancel);
        new_store_button_button_commit = findViewById(R.id.new_store_button_button_commit);

        new_store_button_button_upload_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(
                        Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, IMAGE_REQUEST_CODE);
            }
        });

        new_store_button_input_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Discuss_Add_New_Store.this, "長按可移除圖片", Toast.LENGTH_SHORT).show();
            }
        });
        new_store_button_input_image.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                new_store_button_input_image.setImageBitmap(null);
                return false;
            }
        });

        new_store_button_button_commit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                String create_time = date.format(new Date());

                String store_name = new_store_input_store_name.getText().toString();
                String phonenumber = new_store_input_phonenumber.getText().toString().replace(" ","");
                if (phonenumber.equals("")) {phonenumber = "999";}

                String address = new_store_input_address.getText().toString().replace(" ","");

                String string_of_image = "";
                if (new_store_button_input_image.getDrawable() != null){
                    Bitmap bitmap = ((BitmapDrawable) new_store_button_input_image.getDrawable()).getBitmap();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] imageInByte = baos.toByteArray();
                    string_of_image = Base64.encodeToString(imageInByte,Base64.DEFAULT);
                }

                String is_unknown_store = "1";

                if(store_name.replace(" ","").equals("")){
                    Toast.makeText(Discuss_Add_New_Store.this, "請輸入店名", Toast.LENGTH_LONG).show();
                }else {
                    Connection connection;
                    try {
                        ConSQL c = new ConSQL();
                        connection = c.conclass();
                        String sqlstatement = "INSERT INTO store_info " +
                                "(store_name, create_time, phone_number, address, is_unknown_store) " +
                                "VALUES  (N'" + store_name + "', CONVERT(DATETIME, '" + create_time + "', 102), " +
                                "N'" + phonenumber + "', N'" + address + "', " + is_unknown_store + ")";
                        Statement smt = connection.createStatement();
                        int set = smt.executeUpdate(sqlstatement);

                        connection.close();
                    } catch (Exception e) {
                        Log.d("SqlCon1", e.toString());
                    }

                    if (new_store_button_input_image.getDrawable()!=null){
                        String store_info_id = "";
                        try {
                            ConSQL c = new ConSQL();
                            connection = c.conclass();
                            String sqlstatement = "SELECT store_info_id " +
                                    "FROM store_info " +
                                    "WHERE (store_name = N'" + store_name + "') AND (create_time = CONVERT(DATETIME, '" + create_time + "', 102)) " +
                                    "AND (phone_number = N'" + phonenumber + "') AND (address = N'" + address + "') AND (is_unknown_store = " + is_unknown_store + ")";
                            Statement smt = connection.createStatement();
                            ResultSet set = smt.executeQuery(sqlstatement);
                            while (set.next()){
                                store_info_id = set.getString(1);
                            }
                            connection.close();
                        } catch (Exception e) {
                            Log.d("SqlCon2", e.toString());
                        }

                        try {
                            ConSQL c = new ConSQL();
                            connection = c.conclass();
                            String sqlstatement = "INSERT INTO store_image " +
                                    "(store_info_id, create_time, image, label, is_from_store_owner) " +
                                    "VALUES  (" + store_info_id + ", CONVERT(DATETIME, '" + create_time + "', 102), " +
                                    "'" + string_of_image + "', N'3', 0)";
                            Statement smt = connection.createStatement();
                            int set = smt.executeUpdate(sqlstatement);

                            connection.close();
                        } catch (Exception e) {
                            Log.d("SqlCon3", e.toString());
                        }
                    }

                    Toast.makeText(getApplicationContext(), "已送出", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });

        new_store_button_button_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case IMAGE_REQUEST_CODE://這裡的requestCode是我自己設定的，就是確定返回到那個Activity的標誌
                if (resultCode == RESULT_OK) {//resultcode是setResult裡面設定的code值
                    try {
                        Uri selectedImage = data.getData(); //獲取系統返回的照片的Uri
                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
                        Cursor cursor = getContentResolver().query(selectedImage,
                                filePathColumn, null, null, null);//從系統表中查詢指定Uri對應的照片
                        cursor.moveToFirst();
                        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                        String path = cursor.getString(columnIndex);  //獲取照片路徑
                        cursor.close();
                        Bitmap bitmap = BitmapFactory.decodeFile(path);
                        new_store_button_input_image.setImageBitmap(bitmap);
                    } catch (Exception e) {
                        // TODO Auto-generatedcatch block
                        Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show();
                        Log.d("image",e.toString());
                    }
                }
                break;
        }
    }

    public void changeColor(int resourseColor) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(getApplicationContext(), resourseColor));
        }
    }
}